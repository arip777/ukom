# 🏪 ARIP STORE - Sistem POS Minimarket

> **Minimarket Kardus Island** — Sistem Point of Sale berbasis web dengan tema dusun

---

## 📋 Fitur Lengkap

- 🛒 **Kasir POS** — Input produk via SKU, keranjang belanja, struk print/PDF
- 📦 **Manajemen Produk** — CRUD produk dengan SKU otomatis (ALIAS-NAMA-BERAT)
- 🏷️ **Manajemen Kategori** — CRUD kategori dengan alias 3 karakter
- 📋 **Riwayat Transaksi** — Filter, search, dan print ulang struk
- 🔐 **Autentikasi** — Login/register kasir dengan kode rahasia

## 🧱 Stack Teknologi

| Komponen | Versi |
|----------|-------|
| PHP | 7.2 (native, no framework) |
| MySQL | 5.7 |
| Apache | 2.4 (Ubuntu 18.04) |
| JS | Vanilla (native) |
| CSS | Custom (tema dusun coklat) |

---

## 🐳 Menjalankan dengan Docker

### Prasyarat
- Docker Desktop / Docker Engine
- Docker Compose

### Langkah

```bash
# 1. Clone atau extract project
cd arip-store

# 2. Jalankan Docker
docker-compose up -d

# 3. Tunggu ~30 detik agar MySQL siap

# 4. Akses aplikasi
# Web: http://localhost:8080
# phpMyAdmin: http://localhost:8081
```

### Kredensial Default
| Komponen | Detail |
|----------|--------|
| **Admin Login** | username: `admin` / password: `password` |
| **Kode Registrasi** | `ARIP2024SECRET` |
| **DB User** | arip_user / arip_pass |
| **DB Root** | root |

### Menghentikan Docker
```bash
docker-compose down        # Stop containers
docker-compose down -v     # Stop + hapus volume (reset DB)
```

---

## 🖥️ Menjalankan dengan XAMPP

### Prasyarat
- XAMPP dengan PHP 7.x dan MySQL 5.7

### Langkah

**1. Copy file project**
```
Salin folder `www/` ke htdocs XAMPP:
C:\xampp\htdocs\arip-store\   (Windows)
/opt/lampp/htdocs/arip-store/ (Linux)
```

**2. Setup database**
- Buka phpMyAdmin di `http://localhost/phpmyadmin`
- Import file `xampp_setup.sql`

**3. Edit konfigurasi database**

Buka `www/config/config.php` dan ubah:
```php
// Komentari Docker config:
// define('DB_HOST', 'db');

// Aktifkan XAMPP config:
define('DB_HOST', 'localhost');
define('DB_NAME', 'arip_store');
define('DB_USER', 'root');
define('DB_PASS', '');
```

**4. Akses aplikasi**
```
http://localhost/arip-store/
```

---

## 🔑 Struktur SKU

Format SKU: `ALIAS-NAMASEDERHANA-BERAT`

| Field | Deskripsi | Contoh |
|-------|-----------|--------|
| ALIAS | 3 huruf alias kategori | `MNM` |
| NAMASEDERHANA | Nama produk tanpa spasi/simbol | `AQUAGALON` |
| BERAT | Berat dalam gram | `19000` |

**Contoh SKU:**
- `MNM-AQUAGALON-19000` → Aqua Galon 19kg (Minuman)
- `MKN-INDOMIEGORENG-85` → Indomie Goreng 85g (Makanan)
- `SNK-CHITATOSAPI-68` → Chitato Rasa Sapi 68g (Snack)

---

## 📁 Struktur Folder

```
arip-store/
├── docker-compose.yml          # Docker orchestration
├── xampp_setup.sql             # SQL untuk XAMPP
├── docker/
│   ├── apache/
│   │   ├── Dockerfile          # Apache + PHP 7.2
│   │   └── 000-default.conf    # Virtual host config
│   └── mysql/
│       └── init.sql            # Database initialization
└── www/                        # Web root
    ├── index.php               # Halaman POS Kasir
    ├── login.php               # Login
    ├── register.php            # Registrasi kasir
    ├── logout.php              # Logout
    ├── products.php            # Manajemen produk
    ├── categories.php          # Manajemen kategori
    ├── transactions.php        # Riwayat transaksi
    ├── .htaccess               # Apache config
    ├── config/
    │   ├── config.php          # App configuration
    │   └── database.php        # Database class (PDO)
    ├── includes/
    │   ├── auth.php            # Auth helpers
    │   ├── header.php          # HTML header + navbar
    │   └── footer.php          # HTML footer
    ├── assets/
    │   ├── css/style.css       # Tema dusun coklat
    │   └── js/main.js          # JavaScript POS
    └── api/
        ├── products.php        # REST API produk
        ├── categories.php      # REST API kategori
        └── transactions.php    # REST API transaksi
```

---

## 🔐 Keamanan

- Password di-hash menggunakan `password_hash()` (bcrypt)
- Session-based authentication
- PDO prepared statements (anti SQL injection)
- Registrasi memerlukan kode rahasia
- Konfigurasi kode rahasia: `www/config/config.php` → `REGISTER_SECRET`

---

## 🎨 Tema Desain

Tema **"Dusun Coklat"** dengan palet warna hangat:
- Coklat gelap `#2C1810` — Background navbar
- Coklat tua `#4A2C17` — Elemen utama
- Coklat hangat `#A0622A` — Aksen
- Emas `#C9903A` — Call-to-action
- Krem `#FDF6E3` — Background halaman

Font: **Playfair Display** (judul) + **Lora** (teks) + **DM Mono** (SKU/kode)

---

*ARIP STORE © 2024 — Kardus Island*
