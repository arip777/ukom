<?php
$page_title = 'Kategori';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$categories = db()->fetchAll(
  "SELECT k.*, COUNT(p.id) as product_count
   FROM kategori k LEFT JOIN produk p ON p.kategori_id = k.id
   GROUP BY k.id ORDER BY k.nama"
);
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="main-content">
  <div class="page-header">
    <div class="page-title">
      <div class="title-icon">🏷️</div>
      Manajemen Kategori
    </div>
    <div class="page-subtitle">Kelola kategori produk dan alias SKU.</div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-title">🏷️ Daftar Kategori</div>
      <button class="btn btn-primary btn-sm" onclick="openAddModal()">+ Tambah Kategori</button>
    </div>
    <div class="card-body">
      <?php if (empty($categories)): ?>
      <div class="empty-state">
        <div class="empty-icon">🏷️</div>
        <h3>Belum ada kategori</h3>
        <p>Tambahkan kategori untuk mengelompokkan produk.</p>
      </div>
      <?php else: ?>
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama Kategori</th>
              <th>Alias SKU</th>
              <th>Jumlah Produk</th>
              <th>Dibuat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($categories as $i => $c): ?>
            <tr id="cat-row-<?= $c['id'] ?>">
              <td><?= $i + 1 ?></td>
              <td>
                <div style="font-weight:600;color:var(--brown-dark);"><?= htmlspecialchars($c['nama']) ?></div>
              </td>
              <td>
                <span class="sku-format" style="font-size:0.9rem;font-weight:700;letter-spacing:0.1em;">
                  <?= htmlspecialchars($c['alias']) ?>
                </span>
              </td>
              <td>
                <span class="badge <?= $c['product_count'] > 0 ? 'badge-green' : 'badge-gray' ?>">
                  <?= $c['product_count'] ?> produk
                </span>
              </td>
              <td style="color:var(--brown-light);font-size:0.82rem;">
                <?= date('d M Y', strtotime($c['created_at'])) ?>
              </td>
              <td>
                <div style="display:flex;gap:6px;">
                  <button class="btn btn-primary btn-sm" onclick="openEditModal(<?= htmlspecialchars(json_encode($c)) ?>)">✏️ Edit</button>
                  <button class="btn btn-danger btn-sm" onclick="deleteItem('/api/categories.php?id=<?= $c['id'] ?>',document.getElementById('cat-row-<?= $c['id'] ?>'), 'Hapus kategori <?= addslashes($c['nama']) ?>?')" <?= $c['product_count'] > 0 ? 'title="Ada produk yang menggunakan kategori ini"' : '' ?>>🗑️</button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Add/Edit Category Modal -->
<div id="catModal" class="modal-overlay">
  <div class="modal" style="max-width:420px;">
    <div class="modal-header">
      <span class="modal-title" id="catModalTitle">➕ Tambah Kategori</span>
      <button class="modal-close" onclick="closeModal('catModal')">×</button>
    </div>
    <div class="modal-body">
      <form id="catForm" onsubmit="submitCategory(event)">
        <input type="hidden" id="catId" value="">
        <div class="form-group">
          <label class="form-label">Nama Kategori *</label>
          <input type="text" id="catName" class="form-control" placeholder="e.g. Minuman" required>
        </div>
        <div class="form-group">
          <label class="form-label">Alias SKU (3 karakter) *</label>
          <input type="text" id="catAlias" class="form-control" placeholder="e.g. MNM" maxlength="3"
                 style="font-family:var(--font-mono);font-size:1.2rem;letter-spacing:0.2em;text-transform:uppercase;" required>
          <div class="form-hint">Alias digunakan sebagai prefix SKU produk. Maksimal 3 huruf.</div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('catModal')">Batal</button>
      <button class="btn btn-primary" onclick="document.getElementById('catForm').dispatchEvent(new Event('submit',{cancelable:true}))">
        💾 Simpan
      </button>
    </div>
  </div>
</div>

<script>
function openAddModal() {
  document.getElementById('catModalTitle').textContent = '➕ Tambah Kategori';
  document.getElementById('catForm').reset();
  document.getElementById('catId').value = '';
  openModal('catModal');
}

function openEditModal(cat) {
  document.getElementById('catModalTitle').textContent = '✏️ Edit Kategori';
  document.getElementById('catId').value = cat.id;
  document.getElementById('catName').value = cat.nama;
  document.getElementById('catAlias').value = cat.alias;
  openModal('catModal');
}

document.getElementById('catAlias').addEventListener('input', function() {
  this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '');
});

async function submitCategory(e) {
  e.preventDefault();
  const id = document.getElementById('catId').value;
  const payload = {
    id: id || null,
    nama: document.getElementById('catName').value,
    alias: document.getElementById('catAlias').value.toUpperCase(),
  };

  try {
    const res = await fetch('/api/categories.php', {
      method: id ? 'PUT' : 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      closeModal('catModal');
      setTimeout(() => location.reload(), 800);
    } else {
      showToast(data.error || 'Gagal menyimpan', 'error');
    }
  } catch (err) {
    showToast('Terjadi kesalahan', 'error');
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
