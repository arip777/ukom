<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: /index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Username dan password wajib diisi.';
    } else {
        $kasir = db()->fetchOne("SELECT * FROM kasir WHERE username = ? OR email = ? LIMIT 1", [$username, $username]);
        if ($kasir && password_verify($password, $kasir['password'])) {
            login($kasir);
            header('Location: /index.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - ARIP STORE</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-card-header">
      <div class="auth-logo">🏪</div>
      <div class="auth-app-name">ARIP STORE</div>
      <div class="auth-app-sub">Kardus Island</div>
    </div>
    <div class="auth-card-body">
      <div class="auth-title">Masuk ke Sistem Kasir</div>
      <?php if ($error): ?>
      <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if (isset($_GET['registered'])): ?>
      <div class="alert alert-success">✅ Akun berhasil dibuat. Silakan masuk.</div>
      <?php endif; ?>
      <form method="POST">
        <div class="form-group">
          <label class="form-label">Username / Email</label>
          <input type="text" name="username" class="form-control" placeholder="Masukkan username atau email"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-full btn-lg" style="margin-top:8px;">
          🔐 Masuk
        </button>
      </form>
      <div class="auth-link">
        Belum punya akun? <a href="/register.php">Daftar di sini</a>
      </div>
      <div style="margin-top:16px;padding:12px;background:var(--cream);border-radius:var(--radius);font-size:0.78rem;color:var(--brown-light);">
        <strong>Default Admin:</strong> admin / password
      </div>
    </div>
  </div>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
