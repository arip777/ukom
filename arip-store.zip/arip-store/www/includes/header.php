<?php
require_once __DIR__ . '/auth.php';
$kasir = getCurrentKasir();
$current_page = basename($_SERVER['PHP_SELF'], '.php');

function navActive($page) {
    global $current_page;
    return $current_page === $page ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $page_title ?? 'ARIP STORE' ?> - ARIP STORE</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="/index.php" class="navbar-brand">
    <div class="brand-icon">🏪</div>
    <div>
      <div class="brand-text">ARIP STORE</div>
      <div class="brand-sub">Kardus Island</div>
    </div>
  </a>

  <ul class="navbar-nav">
    <li><a href="/index.php" class="<?= navActive('index') ?>">🛒 Kasir</a></li>
    <li><a href="/products.php" class="<?= navActive('products') ?>">📦 Produk</a></li>
    <li><a href="/categories.php" class="<?= navActive('categories') ?>">🏷️ Kategori</a></li>
    <li><a href="/transactions.php" class="<?= navActive('transactions') ?>">📋 Riwayat</a></li>
  </ul>

  <?php if ($kasir): ?>
  <div class="navbar-user">
    <div class="user-avatar"><?= strtoupper(substr($kasir['username'], 0, 1)) ?></div>
    <span><?= htmlspecialchars($kasir['username']) ?></span>
    <a href="/logout.php" class="btn-logout">Keluar</a>
  </div>
  <?php endif; ?>
</nav>

<div class="batik-border"></div>

<div id="toastContainer" class="toast-container"></div>
