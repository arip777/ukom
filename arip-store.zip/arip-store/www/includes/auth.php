<?php
require_once __DIR__ . '/../config/config.php';

session_name(SESSION_NAME);
session_start();

function isLoggedIn() {
    return isset($_SESSION['kasir_id']) && !empty($_SESSION['kasir_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

function getCurrentKasir() {
    if (!isLoggedIn()) return null;
    return [
        'id' => $_SESSION['kasir_id'],
        'username' => $_SESSION['kasir_username'],
        'email' => $_SESSION['kasir_email'],
    ];
}

function login($kasir) {
    $_SESSION['kasir_id'] = $kasir['id'];
    $_SESSION['kasir_username'] = $kasir['username'];
    $_SESSION['kasir_email'] = $kasir['email'];
}

function logout() {
    session_destroy();
    header('Location: /login.php');
    exit;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function generateTransactionCode() {
    return 'TRX-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}
