<div class="batik-border" style="margin-top: 40px;"></div>
<footer style="text-align:center;padding:16px;font-size:0.78rem;color:var(--brown-light);font-style:italic;background:var(--cream-light);">
  &copy; <?= date('Y') ?> ARIP STORE — Kardus Island. All rights reserved.
</footer>
<script src="/assets/js/main.js"></script>
<?php if (isset($extra_js)) echo $extra_js; ?>
</body>
</html>
