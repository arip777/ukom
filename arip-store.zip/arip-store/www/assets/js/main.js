// ARIP STORE - Main JavaScript

// Toast notification
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(60px)';
    toast.style.transition = '0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Modal helpers
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('active'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('active'); document.body.style.overflow = ''; }
}
function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
  document.body.style.overflow = '';
}

// Close modal on overlay click
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) closeAllModals();
});

// Format rupiah
function formatRp(n) {
  n = parseFloat(n) || 0;
  return 'Rp ' + n.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function unformatRp(str) {
  return parseFloat(str.replace(/[^0-9]/g, '')) || 0;
}

// Confirm dialog
function confirmAction(message, callback) {
  if (confirm(message)) callback();
}

// Generic DELETE via fetch
function deleteItem(url, row, confirmMsg) {
  confirmAction(confirmMsg || 'Yakin ingin menghapus?', async () => {
    try {
      const res = await fetch(url, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        if (row) row.remove();
        showToast(data.message || 'Berhasil dihapus', 'success');
      } else {
        showToast(data.error || 'Gagal menghapus', 'error');
      }
    } catch (err) {
      showToast('Terjadi kesalahan', 'error');
    }
  });
}

// ==================== POS CART ====================
let cart = [];

function getCartItemByProductId(productId) {
  return cart.find(i => i.id == productId);
}

function addToCart(product, qty = 1) {
  const existing = getCartItemByProductId(product.id);
  if (existing) {
    if (existing.qty + qty > product.stock) {
      showToast('Stok tidak mencukupi!', 'error');
      return false;
    }
    existing.qty += qty;
  } else {
    if (qty > product.stock) {
      showToast('Stok tidak mencukupi!', 'error');
      return false;
    }
    cart.push({
      id: product.id,
      name: product.name,
      sku: product.sku,
      price: parseFloat(product.price),
      discount: parseFloat(product.discount) || 0,
      stock: parseInt(product.stock),
      qty: qty
    });
  }
  renderCart();
  return true;
}

function removeFromCart(productId) {
  cart = cart.filter(i => i.id != productId);
  renderCart();
}

function updateCartQty(productId, newQty) {
  const item = getCartItemByProductId(productId);
  if (!item) return;
  if (newQty <= 0) {
    removeFromCart(productId);
    return;
  }
  if (newQty > item.stock) {
    showToast('Melebihi stok tersedia!', 'error');
    return;
  }
  item.qty = newQty;
  renderCart();
}

function getItemSubtotal(item) {
  const discounted = item.price * (1 - item.discount / 100);
  return discounted * item.qty;
}

function getCartTotals() {
  let subtotal = 0, totalDiscount = 0;
  cart.forEach(item => {
    subtotal += item.price * item.qty;
    totalDiscount += (item.price * item.discount / 100) * item.qty;
  });
  const grandTotal = subtotal - totalDiscount;
  return { subtotal, totalDiscount, grandTotal };
}

function renderCart() {
  const cartItems = document.getElementById('cartItems');
  const cartCount = document.getElementById('cartCount');
  const emptyState = document.getElementById('cartEmpty');
  if (!cartItems) return;

  if (cart.length === 0) {
    cartItems.innerHTML = '';
    if (emptyState) emptyState.style.display = 'flex';
    if (cartCount) cartCount.textContent = '0';
    updateTotals();
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  if (cartCount) cartCount.textContent = cart.reduce((s, i) => s + i.qty, 0);

  cartItems.innerHTML = cart.map(item => {
    const subtotal = getItemSubtotal(item);
    const discountBadge = item.discount > 0
      ? `<span class="discount-tag">${item.discount}% off</span>` : '';
    return `
      <div class="cart-item" id="cartItem-${item.id}">
        <div class="cart-item-info">
          <div class="cart-item-name">${escHtml(item.name)} ${discountBadge}</div>
          <div class="cart-item-sku">${escHtml(item.sku)}</div>
          <div class="cart-item-price">${formatRp(item.price)}${item.discount > 0 ? ` → ${formatRp(item.price * (1 - item.discount / 100))}` : ''}</div>
        </div>
        <div class="cart-item-controls">
          <button class="qty-btn minus" onclick="updateCartQty(${item.id}, ${item.qty - 1})">−</button>
          <span class="qty-value">${item.qty}</span>
          <button class="qty-btn plus" onclick="updateCartQty(${item.id}, ${item.qty + 1})">+</button>
        </div>
        <div class="cart-item-subtotal">${formatRp(subtotal)}</div>
      </div>`;
  }).join('');

  updateTotals();
}

function updateTotals() {
  const { subtotal, totalDiscount, grandTotal } = getCartTotals();
  const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  setTxt('subtotalVal', formatRp(subtotal));
  setTxt('discountVal', totalDiscount > 0 ? `- ${formatRp(totalDiscount)}` : formatRp(0));
  setTxt('grandTotalVal', formatRp(grandTotal));

  const bayarInput = document.getElementById('bayarInput');
  if (bayarInput) calculateKembalian();

  const btnCheckout = document.getElementById('btnCheckout');
  if (btnCheckout) btnCheckout.disabled = cart.length === 0;
}

function calculateKembalian() {
  const bayar = unformatRp(document.getElementById('bayarInput')?.value || '0');
  const { grandTotal } = getCartTotals();
  const kembalian = bayar - grandTotal;
  const el = document.getElementById('kembalianVal');
  if (el) {
    el.textContent = kembalian >= 0 ? formatRp(kembalian) : '—';
    el.parentElement.style.borderColor = kembalian >= 0
      ? 'rgba(201, 144, 58, 0.3)' : 'rgba(139, 58, 42, 0.3)';
  }
}

function setQuickAmount(amount) {
  const input = document.getElementById('bayarInput');
  if (input) {
    input.value = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    calculateKembalian();
  }
}

function clearCart() {
  cart = [];
  renderCart();
  const bayarInput = document.getElementById('bayarInput');
  if (bayarInput) { bayarInput.value = ''; calculateKembalian(); }
}

// SKU lookup
let skuSearchTimeout = null;

function lookupSKU(sku) {
  sku = sku.trim().toUpperCase();
  if (!sku) {
    hideProductFound();
    return;
  }

  clearTimeout(skuSearchTimeout);
  skuSearchTimeout = setTimeout(async () => {
    try {
      const res = await fetch(`/api/products.php?sku=${encodeURIComponent(sku)}`);
      const data = await res.json();
      if (data.success && data.product) {
        showProductFound(data.product);
      } else {
        hideProductFound();
      }
    } catch (e) {
      hideProductFound();
    }
  }, 300);
}

function showProductFound(product) {
  const card = document.getElementById('productFoundCard');
  if (!card) return;
  document.getElementById('pfName').textContent = product.name;
  document.getElementById('pfSku').textContent = product.sku;
  const discountedPrice = product.price * (1 - product.discount / 100);
  document.getElementById('pfPrice').textContent = product.discount > 0
    ? `${formatRp(discountedPrice)} (disc ${product.discount}%)`
    : formatRp(product.price);
  document.getElementById('pfStock').textContent = `Stok: ${product.stock}`;
  card.classList.add('visible');
  card.dataset.product = JSON.stringify(product);
}

function hideProductFound() {
  const card = document.getElementById('productFoundCard');
  if (card) card.classList.remove('visible');
}

function addFoundProductToCart() {
  const card = document.getElementById('productFoundCard');
  if (!card || !card.dataset.product) return;
  const product = JSON.parse(card.dataset.product);
  if (addToCart(product)) {
    showToast(`${product.name} ditambahkan ke keranjang`, 'success');
    const skuInput = document.getElementById('skuInput');
    if (skuInput) { skuInput.value = ''; skuInput.focus(); }
    hideProductFound();
  }
}

// Submit transaction
async function submitTransaction() {
  if (cart.length === 0) {
    showToast('Keranjang kosong!', 'error');
    return;
  }

  const bayar = unformatRp(document.getElementById('bayarInput')?.value || '0');
  const { grandTotal } = getCartTotals();

  if (bayar < grandTotal) {
    showToast('Uang bayar kurang!', 'error');
    return;
  }

  const btn = document.getElementById('btnCheckout');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Memproses...'; }

  try {
    const res = await fetch('/api/transactions.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cart, bayar, grandTotal })
    });
    const data = await res.json();

    if (data.success) {
      showToast('Transaksi berhasil!', 'success');
      openReceiptModal(data.transaction);
      clearCart();
    } else {
      showToast(data.error || 'Gagal memproses transaksi', 'error');
    }
  } catch (e) {
    showToast('Terjadi kesalahan', 'error');
  } finally {
    if (btn) { btn.disabled = cart.length === 0; btn.innerHTML = '🛒 PROSES TRANSAKSI'; }
  }
}

function openReceiptModal(transaction) {
  const modal = document.getElementById('receiptModal');
  const content = document.getElementById('receiptContent');
  if (!modal || !content) return;

  const bayar = unformatRp(document.getElementById('bayarInput')?.value || transaction.grand_total);
  const kembalian = Math.max(0, bayar - transaction.grand_total);

  let itemsHtml = '';
  transaction.products.forEach(item => {
    const price = item.price * (1 - (item.discount || 0) / 100);
    itemsHtml += `
      <div class="receipt-item">
        <div class="receipt-item-name">${escHtml(item.name)}<br><small>${item.qty}x @ ${formatRp(price)}</small></div>
        <div class="receipt-item-amount">${formatRp(price * item.qty)}</div>
      </div>`;
  });

  content.innerHTML = `
    <div class="receipt-container">
      <div class="receipt-header">
        <h1>🏪 ARIP STORE</h1>
        <p>Kardus Island</p>
        <p>Tel: +62 812-3456-7890</p>
      </div>
      <hr class="receipt-divider">
      <div style="display:flex;justify-content:space-between;font-size:0.8rem;margin-bottom:8px;">
        <span>Kode: <strong>${transaction.kode}</strong></span>
        <span>${new Date().toLocaleString('id-ID')}</span>
      </div>
      <hr class="receipt-divider">
      <div class="receipt-items">${itemsHtml}</div>
      <hr class="receipt-divider">
      <div class="receipt-total-row receipt-grand">
        <span>TOTAL</span>
        <span>${formatRp(transaction.grand_total)}</span>
      </div>
      <div class="receipt-total-row">
        <span>Bayar</span>
        <span>${formatRp(bayar)}</span>
      </div>
      <div class="receipt-total-row">
        <span>Kembalian</span>
        <span>${formatRp(kembalian)}</span>
      </div>
      <hr class="receipt-divider">
      <div class="receipt-footer">
        <p>Terima kasih telah berbelanja!</p>
        <p>Selamat datang kembali 🙏</p>
        <p style="margin-top:8px;font-size:0.7rem;">— ARIP STORE, Kardus Island —</p>
      </div>
    </div>`;

  modal.classList.add('active');
}

function printReceipt() {
  const content = document.getElementById('receiptContent')?.innerHTML;
  if (!content) return;
  const w = window.open('', '_blank', 'width=400,height=600');
  w.document.write(`<!DOCTYPE html><html><head>
    <title>Struk - ARIP STORE</title>
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body { font-family: 'Courier New', monospace; font-size: 12px; background: white; }
      .receipt-container { max-width: 300px; margin: 0 auto; padding: 16px; }
      .receipt-header { text-align: center; margin-bottom: 12px; }
      .receipt-header h1 { font-size: 18px; font-weight: bold; }
      .receipt-header p { font-size: 11px; }
      hr { border: none; border-top: 1px dashed #666; margin: 8px 0; }
      .receipt-item { display: flex; justify-content: space-between; margin: 3px 0; font-size: 11px; }
      .receipt-item-name { flex: 1; }
      .receipt-item-amount { text-align: right; white-space: nowrap; margin-left: 8px; }
      .receipt-total-row { display: flex; justify-content: space-between; font-weight: bold; margin: 3px 0; }
      .receipt-grand { font-size: 14px; border-top: 1px solid #333; padding-top: 4px; margin-top: 4px; }
      .receipt-footer { text-align: center; font-size: 10px; color: #555; margin-top: 12px; }
    </style>
  </head><body>${content}<script>window.onload=function(){window.print();window.close()}<\/script></body></html>`);
  w.document.close();
}

function downloadReceiptPDF() {
  const trxCode = document.querySelector('#receiptContent strong')?.textContent || 'receipt';
  printReceipt();
}

// Escape HTML
function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Format number input
document.addEventListener('input', function(e) {
  if (e.target.id === 'bayarInput') {
    let raw = e.target.value.replace(/[^0-9]/g, '');
    if (raw) {
      e.target.value = parseInt(raw).toLocaleString('id-ID');
    }
    calculateKembalian();
  }
});

// SKU Enter key
document.addEventListener('keydown', function(e) {
  if (e.target.id === 'skuInput' && e.key === 'Enter') {
    addFoundProductToCart();
  }
});

// Init
document.addEventListener('DOMContentLoaded', function() {
  renderCart();
});
