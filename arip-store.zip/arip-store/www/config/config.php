<?php
// Application Configuration
define('APP_NAME', 'ARIP STORE');
define('APP_TAGLINE', 'Minimarket Kardus Island');
define('APP_ADDRESS', 'Kardus Island');
define('APP_PHONE', '+62 812-3456-7890');

// Registration Secret Key
define('REGISTER_SECRET', 'ARIP2024SECRET');

// Database Configuration (Docker)
define('DB_HOST', 'db');
define('DB_PORT', '3306');
define('DB_NAME', 'arip_store');
define('DB_USER', 'arip_user');
define('DB_PASS', 'arip_pass');

// For XAMPP - uncomment below and comment Docker config above
// define('DB_HOST', 'localhost');
// define('DB_PORT', '3306');
// define('DB_NAME', 'arip_store');
// define('DB_USER', 'root');
// define('DB_PASS', '');

// Session config
define('SESSION_NAME', 'arip_session');
define('BASE_URL', '');

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
