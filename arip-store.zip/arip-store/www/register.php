<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: /index.php');
    exit;
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $secret = trim($_POST['secret'] ?? '');

    if (empty($username) || empty($email) || empty($password) || empty($secret)) {
        $error = 'Semua field wajib diisi.';
    } elseif ($secret !== REGISTER_SECRET) {
        $error = 'Kode rahasia tidak valid.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } else {
        $existing = db()->fetchOne("SELECT id FROM kasir WHERE username = ? OR email = ?", [$username, $email]);
        if ($existing) {
            $error = 'Username atau email sudah terdaftar.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            db()->insert("INSERT INTO kasir (username, email, password) VALUES (?,?,?)", [$username, $email, $hashed]);
            header('Location: /login.php?registered=1');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar - ARIP STORE</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-card" style="max-width: 480px;">
    <div class="auth-card-header">
      <div class="auth-logo">🏪</div>
      <div class="auth-app-name">ARIP STORE</div>
      <div class="auth-app-sub">Registrasi Kasir Baru</div>
    </div>
    <div class="auth-card-body">
      <div class="auth-title">Buat Akun Kasir</div>
      <?php if ($error): ?>
      <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <form method="POST">
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" placeholder="username_kasir"
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" placeholder="email@contoh.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          </div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Min. 6 karakter" required>
          </div>
          <div class="form-group">
            <label class="form-label">Konfirmasi Password</label>
            <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Kode Rahasia</label>
          <input type="password" name="secret" class="form-control" placeholder="Masukkan kode rahasia registrasi" required>
          <div class="form-hint">Kode rahasia diperlukan untuk keamanan sistem.</div>
        </div>
        <button type="submit" class="btn btn-primary btn-full btn-lg" style="margin-top:8px;">
          ✅ Buat Akun
        </button>
      </form>
      <div class="auth-link">
        Sudah punya akun? <a href="/login.php">Masuk di sini</a>
      </div>
    </div>
  </div>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
