<?php
$page_title = 'Manajemen Produk';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$categories = db()->fetchAll("SELECT * FROM kategori ORDER BY nama");
$search = trim($_GET['search'] ?? '');
$cat_filter = intval($_GET['category'] ?? 0);
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 15;
$offset = ($page - 1) * $per_page;

$where = ['1=1'];
$params = [];
if ($search) { $where[] = '(p.name LIKE ? OR p.sku LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($cat_filter) { $where[] = 'p.kategori_id = ?'; $params[] = $cat_filter; }
$where_sql = implode(' AND ', $where);

$total = db()->fetchOne("SELECT COUNT(*) as cnt FROM produk p WHERE $where_sql", $params)['cnt'];
$total_pages = ceil($total / $per_page);

$products = db()->fetchAll(
  "SELECT p.*, k.nama as kategori_nama, k.alias as kategori_alias
   FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id
   WHERE $where_sql ORDER BY p.created_at DESC LIMIT ? OFFSET ?",
  array_merge($params, [$per_page, $offset])
);

$stats = db()->fetchOne("SELECT COUNT(*) as total, SUM(stock) as total_stock, SUM(sold) as total_sold, SUM(price*stock) as nilai_stok FROM produk");
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="main-content">
  <div class="page-header">
    <div class="page-title">
      <div class="title-icon">📦</div>
      Manajemen Produk
    </div>
    <div class="page-subtitle">Kelola semua produk di toko Anda.</div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card brown">
      <div class="stat-icon brown">📦</div>
      <div class="stat-value"><?= number_format($stats['total']) ?></div>
      <div class="stat-label">Total Produk</div>
    </div>
    <div class="stat-card gold">
      <div class="stat-icon gold">🏷️</div>
      <div class="stat-value"><?= number_format($stats['total_stock'] ?? 0) ?></div>
      <div class="stat-label">Total Stok</div>
    </div>
    <div class="stat-card green">
      <div class="stat-icon green">✅</div>
      <div class="stat-value"><?= number_format($stats['total_sold'] ?? 0) ?></div>
      <div class="stat-label">Total Terjual</div>
    </div>
    <div class="stat-card red">
      <div class="stat-icon red">💰</div>
      <div class="stat-value" style="font-size:1.2rem;"><?= 'Rp ' . number_format($stats['nilai_stok'] ?? 0, 0, ',', '.') ?></div>
      <div class="stat-label">Nilai Stok</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-title">📦 Daftar Produk</div>
      <button class="btn btn-primary btn-sm" onclick="openAddModal()">+ Tambah Produk</button>
    </div>
    <div class="card-body">
      <!-- Filter Bar -->
      <div class="filter-bar">
        <div class="search-input-wrapper" style="flex:1;min-width:240px;">
          <span class="search-icon">🔍</span>
          <input type="text" class="form-control" placeholder="Cari nama atau SKU..." id="searchInput"
                 value="<?= htmlspecialchars($search) ?>">
        </div>
        <select class="form-control" id="catFilter" style="width:180px;">
          <option value="">Semua Kategori</option>
          <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $cat_filter == $c['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($c['nama']) ?>
          </option>
          <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" onclick="applyFilter()">Cari</button>
        <?php if ($search || $cat_filter): ?>
        <a href="/products.php" class="btn btn-outline btn-sm">Reset</a>
        <?php endif; ?>
      </div>

      <?php if (empty($products)): ?>
      <div class="empty-state">
        <div class="empty-icon">📦</div>
        <h3>Tidak ada produk</h3>
        <p>Belum ada produk yang ditambahkan. Klik "+ Tambah Produk" untuk memulai.</p>
      </div>
      <?php else: ?>
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama Produk</th>
              <th>SKU</th>
              <th>Kategori</th>
              <th>Harga</th>
              <th>Diskon</th>
              <th>Berat</th>
              <th>Stok</th>
              <th>Terjual</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="productTableBody">
            <?php foreach ($products as $i => $p): ?>
            <tr id="product-row-<?= $p['id'] ?>">
              <td><?= $offset + $i + 1 ?></td>
              <td>
                <div style="font-weight:600;color:var(--brown-dark);"><?= htmlspecialchars($p['name']) ?></div>
                <div style="font-size:0.75rem;color:var(--brown-light);">ID: <?= $p['id'] ?></div>
              </td>
              <td><span class="sku"><?= htmlspecialchars($p['sku']) ?></span></td>
              <td>
                <?php if ($p['kategori_nama']): ?>
                <span class="badge badge-brown"><?= htmlspecialchars($p['kategori_alias']) ?></span>
                <span style="font-size:0.82rem;"> <?= htmlspecialchars($p['kategori_nama']) ?></span>
                <?php else: ?>
                <span class="badge badge-gray">—</span>
                <?php endif; ?>
              </td>
              <td><strong>Rp <?= number_format($p['price'], 0, ',', '.') ?></strong></td>
              <td>
                <?php if ($p['discount'] > 0): ?>
                <span class="badge badge-red"><?= $p['discount'] ?>%</span>
                <?php else: ?>
                <span style="color:var(--brown-pale);">—</span>
                <?php endif; ?>
              </td>
              <td><?= number_format($p['berat']) ?> g</td>
              <td>
                <?php
                $stockClass = $p['stock'] <= 0 ? 'badge-red' : ($p['stock'] <= 5 ? 'badge-gold' : 'badge-green');
                ?>
                <span class="badge <?= $stockClass ?>"><?= $p['stock'] ?></span>
              </td>
              <td><?= number_format($p['sold']) ?></td>
              <td>
                <div style="display:flex;gap:6px;">
                  <button class="btn btn-primary btn-sm" onclick="openEditModal(<?= htmlspecialchars(json_encode($p)) ?>)">✏️ Edit</button>
                  <button class="btn btn-danger btn-sm" onclick="deleteItem('/api/products.php?id=<?= $p['id'] ?>',document.getElementById('product-row-<?= $p['id'] ?>'), 'Hapus produk <?= addslashes($p['name']) ?>?')">🗑️</button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($total_pages > 1): ?>
      <div class="pagination">
        <?php for ($p2 = 1; $p2 <= $total_pages; $p2++): ?>
        <a href="?page=<?= $p2 ?>&search=<?= urlencode($search) ?>&category=<?= $cat_filter ?>"
           class="page-btn <?= $p2 == $page ? 'active' : '' ?>"><?= $p2 ?></a>
        <?php endfor; ?>
      </div>
      <div style="text-align:center;font-size:0.8rem;color:var(--brown-light);margin-top:4px;">
        Menampilkan <?= count($products) ?> dari <?= $total ?> produk
      </div>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Add/Edit Product Modal -->
<div id="productModal" class="modal-overlay">
  <div class="modal" style="max-width:600px;">
    <div class="modal-header">
      <span class="modal-title" id="productModalTitle">➕ Tambah Produk</span>
      <button class="modal-close" onclick="closeModal('productModal')">×</button>
    </div>
    <div class="modal-body">
      <form id="productForm" onsubmit="submitProduct(event)">
        <input type="hidden" id="productId" value="">
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Nama Produk *</label>
            <input type="text" id="pName" class="form-control" placeholder="e.g. Aqua Galon 19L" required>
          </div>
          <div class="form-group">
            <label class="form-label">Kategori *</label>
            <select id="pKategori" class="form-control" required onchange="updateSkuPreview()">
              <option value="">-- Pilih Kategori --</option>
              <?php foreach ($categories as $c): ?>
              <option value="<?= $c['id'] ?>" data-alias="<?= $c['alias'] ?>"><?= htmlspecialchars($c['nama']) ?> (<?= $c['alias'] ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Harga (Rp) *</label>
            <input type="number" id="pPrice" class="form-control" placeholder="22000" min="0" step="100" required>
          </div>
          <div class="form-group">
            <label class="form-label">Berat (gram) *</label>
            <input type="number" id="pBerat" class="form-control" placeholder="19000" min="0" required oninput="updateSkuPreview()">
          </div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Stok</label>
            <input type="number" id="pStock" class="form-control" placeholder="0" min="0" value="0">
          </div>
          <div class="form-group">
            <label class="form-label">Diskon (%)</label>
            <input type="number" id="pDiscount" class="form-control" placeholder="0" min="0" max="100" value="0" step="0.01">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">SKU</label>
          <input type="text" id="pSku" class="form-control" placeholder="Auto-generated atau isi manual" style="font-family:var(--font-mono);">
          <div class="form-hint" id="skuPreviewHint">Format: ALIAS-NAMA-BERAT (contoh: MNM-AQUAGALON-19000)</div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('productModal')">Batal</button>
      <button class="btn btn-primary" onclick="document.getElementById('productForm').dispatchEvent(new Event('submit',{cancelable:true}))">
        💾 Simpan
      </button>
    </div>
  </div>
</div>

<script>
function applyFilter() {
  const s = document.getElementById('searchInput').value;
  const c = document.getElementById('catFilter').value;
  window.location.href = `/products.php?search=${encodeURIComponent(s)}&category=${c}`;
}
document.getElementById('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') applyFilter(); });

function generateSku(alias, name, berat) {
  const nameSlug = name.toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 12);
  return `${alias}-${nameSlug}-${berat}`;
}

function updateSkuPreview() {
  const nameEl = document.getElementById('pName');
  const katEl = document.getElementById('pKategori');
  const beratEl = document.getElementById('pBerat');
  const skuEl = document.getElementById('pSku');

  if (!document.getElementById('productId').value) {
    // Only auto-generate for new products
    const alias = katEl.options[katEl.selectedIndex]?.dataset.alias || '';
    const name = nameEl.value;
    const berat = beratEl.value;
    if (alias && name && berat) {
      skuEl.value = generateSku(alias, name, berat);
    }
  }
}

document.getElementById('pName').addEventListener('input', updateSkuPreview);

function openAddModal() {
  document.getElementById('productModalTitle').textContent = '➕ Tambah Produk';
  document.getElementById('productForm').reset();
  document.getElementById('productId').value = '';
  document.getElementById('pDiscount').value = '0';
  document.getElementById('pStock').value = '0';
  document.getElementById('pSku').value = '';
  openModal('productModal');
}

function openEditModal(product) {
  document.getElementById('productModalTitle').textContent = '✏️ Edit Produk';
  document.getElementById('productId').value = product.id;
  document.getElementById('pName').value = product.name;
  document.getElementById('pKategori').value = product.kategori_id || '';
  document.getElementById('pPrice').value = product.price;
  document.getElementById('pBerat').value = product.berat;
  document.getElementById('pStock').value = product.stock;
  document.getElementById('pDiscount').value = product.discount;
  document.getElementById('pSku').value = product.sku;
  openModal('productModal');
}

async function submitProduct(e) {
  e.preventDefault();
  const id = document.getElementById('productId').value;
  const payload = {
    id: id || null,
    name: document.getElementById('pName').value,
    kategori_id: document.getElementById('pKategori').value || null,
    price: document.getElementById('pPrice').value,
    berat: document.getElementById('pBerat').value,
    stock: document.getElementById('pStock').value,
    discount: document.getElementById('pDiscount').value || 0,
    sku: document.getElementById('pSku').value,
  };

  try {
    const res = await fetch('/api/products.php', {
      method: id ? 'PUT' : 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      closeModal('productModal');
      setTimeout(() => location.reload(), 800);
    } else {
      showToast(data.error || 'Gagal menyimpan', 'error');
    }
  } catch (err) {
    showToast('Terjadi kesalahan', 'error');
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
