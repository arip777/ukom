<?php
$page_title = 'Kasir';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$kasir = getCurrentKasir();
$today_total = db()->fetchOne("SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi WHERE DATE(created_at) = CURDATE()");
$today_count = db()->fetchOne("SELECT COUNT(*) as cnt FROM transaksi WHERE DATE(created_at) = CURDATE()");
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="main-content">
  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <div class="page-title">
        <div class="title-icon">🛒</div>
        Kasir - Point of Sale
      </div>
      <div class="page-subtitle">Selamat datang, <?= htmlspecialchars($kasir['username']) ?>! Input SKU untuk menambah produk.</div>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <div style="text-align:right;">
        <div style="font-size:0.75rem;color:var(--brown-light);text-transform:uppercase;letter-spacing:0.08em;">Omzet Hari Ini</div>
        <div style="font-family:var(--font-display);font-size:1.2rem;font-weight:700;color:var(--brown-warm);">
          <?= 'Rp ' . number_format($today_total['total'], 0, ',', '.') ?>
        </div>
      </div>
      <div style="width:1px;height:40px;background:var(--cream-dark);"></div>
      <div style="text-align:right;">
        <div style="font-size:0.75rem;color:var(--brown-light);text-transform:uppercase;letter-spacing:0.08em;">Transaksi</div>
        <div style="font-family:var(--font-display);font-size:1.2rem;font-weight:700;color:var(--accent-gold);">
          <?= $today_count['cnt'] ?>
        </div>
      </div>
    </div>
  </div>

  <div class="pos-layout">
    <!-- LEFT: SKU Input + Cart -->
    <div class="pos-left">
      <!-- SKU Input -->
      <div class="sku-input-section">
        <div style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;">
          <span style="font-family:var(--font-display);font-size:0.9rem;font-weight:600;color:var(--brown-dark);">
            🔍 Scan / Input SKU Produk
          </span>
          <span class="sku-format">FORMAT: KAT-NAMA-BERAT</span>
        </div>
        <div class="sku-input-wrapper">
          <input type="text" id="skuInput" class="sku-input" placeholder="Ketik atau scan SKU produk, tekan Enter..."
                 oninput="lookupSKU(this.value)" autocomplete="off" autocorrect="off" autofocus>
          <button class="btn btn-primary" onclick="addFoundProductToCart()">+ Tambah</button>
        </div>
        <!-- Product Found Preview -->
        <div id="productFoundCard" class="product-found-card" style="margin-top:12px;">
          <div class="product-found-icon">📦</div>
          <div class="product-found-details">
            <div class="product-found-name" id="pfName">—</div>
            <div class="product-found-sku" id="pfSku">—</div>
            <div class="product-found-price" id="pfPrice">—</div>
            <div class="product-found-stock" id="pfStock">—</div>
          </div>
          <button class="btn btn-success" onclick="addFoundProductToCart()">+ Tambah</button>
        </div>
      </div>

      <!-- Cart -->
      <div class="cart-section">
        <div class="cart-header">
          <div style="display:flex;align-items:center;gap:8px;">
            <span class="card-title">🛒 Keranjang Belanja</span>
            <span id="cartCount" style="background:var(--brown-warm);color:white;border-radius:12px;padding:2px 9px;font-size:0.78rem;font-weight:700;">0</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="if(cart.length){confirmAction('Kosongkan keranjang?',clearCart)}">🗑️ Kosongkan</button>
        </div>
        <div class="cart-items" id="cartItems">
          <div id="cartEmpty" class="cart-empty" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;">
            <div class="empty-icon">🛒</div>
            <p>Keranjang masih kosong.<br>Scan atau ketik SKU produk di atas.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT: Checkout Panel -->
    <div class="pos-right">
      <div class="checkout-panel">
        <div class="checkout-header">
          <h3>📄 Rincian Pembayaran</h3>
        </div>
        <div class="checkout-totals">
          <div class="total-row">
            <span class="label">Subtotal</span>
            <span class="value" id="subtotalVal">Rp 0</span>
          </div>
          <div class="total-row">
            <span class="label">Diskon</span>
            <span class="value" id="discountVal" style="color: #C04A3A;">Rp 0</span>
          </div>
          <div class="total-row grand">
            <span class="label">TOTAL</span>
            <span class="value" id="grandTotalVal">Rp 0</span>
          </div>
        </div>
        <div class="payment-section">
          <!-- Quick amounts -->
          <div style="font-size:0.72rem;color:var(--brown-pale);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;">Jumlah Cepat</div>
          <div class="quick-amounts">
            <button class="quick-btn" onclick="setQuickAmount(5000)">5.000</button>
            <button class="quick-btn" onclick="setQuickAmount(10000)">10.000</button>
            <button class="quick-btn" onclick="setQuickAmount(20000)">20.000</button>
            <button class="quick-btn" onclick="setQuickAmount(50000)">50.000</button>
            <button class="quick-btn" onclick="setQuickAmount(100000)">100.000</button>
            <button class="quick-btn" onclick="setQuickAmount(200000)">200.000</button>
          </div>
          <div class="payment-input-group">
            <label>Uang Bayar</label>
            <input type="text" id="bayarInput" class="payment-input" placeholder="0" oninput="calculateKembalian()">
          </div>
          <div class="kembalian-display">
            <span class="k-label">💵 Kembalian</span>
            <span class="k-value" id="kembalianVal">—</span>
          </div>
          <button id="btnCheckout" class="btn-checkout" onclick="submitTransaction()" disabled>
            🛒 PROSES TRANSAKSI
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Receipt Modal -->
<div id="receiptModal" class="modal-overlay">
  <div class="modal" style="max-width:460px;">
    <div class="modal-header">
      <span class="modal-title">🧾 Struk Transaksi</span>
      <button class="modal-close" onclick="closeModal('receiptModal');location.reload()">×</button>
    </div>
    <div class="modal-body">
      <div id="receiptContent"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('receiptModal');location.reload()">✕ Tutup</button>
      <button class="btn btn-primary" onclick="printReceipt()">🖨️ Print Struk</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
