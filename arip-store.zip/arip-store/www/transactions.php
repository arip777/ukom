<?php
$page_title = 'Riwayat Transaksi';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$search = trim($_GET['search'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

$where = ['1=1'];
$params = [];
if ($search) { $where[] = '(t.kode LIKE ? OR k.username LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($date_from) { $where[] = 'DATE(t.created_at) >= ?'; $params[] = $date_from; }
if ($date_to) { $where[] = 'DATE(t.created_at) <= ?'; $params[] = $date_to; }
$where_sql = implode(' AND ', $where);

$total = db()->fetchOne("SELECT COUNT(*) as cnt FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id WHERE $where_sql", $params)['cnt'];
$total_pages = ceil($total / $per_page);

$transactions = db()->fetchAll(
  "SELECT t.*, k.username as kasir_username
   FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id
   WHERE $where_sql ORDER BY t.created_at DESC LIMIT ? OFFSET ?",
  array_merge($params, [$per_page, $offset])
);

$stats = db()->fetchOne("SELECT COUNT(*) as total, COALESCE(SUM(grand_total),0) as total_revenue FROM transaksi");
$today_stats = db()->fetchOne("SELECT COUNT(*) as cnt, COALESCE(SUM(grand_total),0) as rev FROM transaksi WHERE DATE(created_at) = CURDATE()");
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="main-content">
  <div class="page-header">
    <div class="page-title">
      <div class="title-icon">📋</div>
      Riwayat Transaksi
    </div>
    <div class="page-subtitle">Lihat semua riwayat transaksi penjualan.</div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card brown">
      <div class="stat-icon brown">📋</div>
      <div class="stat-value"><?= number_format($stats['total']) ?></div>
      <div class="stat-label">Total Transaksi</div>
    </div>
    <div class="stat-card gold">
      <div class="stat-icon gold">💵</div>
      <div class="stat-value" style="font-size:1.2rem;">Rp <?= number_format($stats['total_revenue'], 0, ',', '.') ?></div>
      <div class="stat-label">Total Pendapatan</div>
    </div>
    <div class="stat-card green">
      <div class="stat-icon green">🗓️</div>
      <div class="stat-value"><?= $today_stats['cnt'] ?></div>
      <div class="stat-label">Transaksi Hari Ini</div>
    </div>
    <div class="stat-card red">
      <div class="stat-icon red">💰</div>
      <div class="stat-value" style="font-size:1.2rem;">Rp <?= number_format($today_stats['rev'], 0, ',', '.') ?></div>
      <div class="stat-label">Omzet Hari Ini</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-title">📋 Daftar Transaksi</div>
    </div>
    <div class="card-body">
      <!-- Filter -->
      <div class="filter-bar">
        <div class="search-input-wrapper" style="flex:1;min-width:200px;">
          <span class="search-icon">🔍</span>
          <input type="text" class="form-control" placeholder="Cari kode transaksi atau kasir..." id="searchInput"
                 value="<?= htmlspecialchars($search) ?>">
        </div>
        <input type="date" class="form-control" id="dateFrom" value="<?= $date_from ?>" style="width:160px;">
        <input type="date" class="form-control" id="dateTo" value="<?= $date_to ?>" style="width:160px;">
        <button class="btn btn-primary btn-sm" onclick="applyFilter()">Cari</button>
        <?php if ($search || $date_from || $date_to): ?>
        <a href="/transactions.php" class="btn btn-outline btn-sm">Reset</a>
        <?php endif; ?>
      </div>

      <?php if (empty($transactions)): ?>
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <h3>Belum ada transaksi</h3>
        <p>Transaksi yang dilakukan akan tampil di sini.</p>
      </div>
      <?php else: ?>
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Kode Transaksi</th>
              <th>Kasir</th>
              <th>Produk</th>
              <th>Grand Total</th>
              <th>Waktu</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($transactions as $i => $t): ?>
            <?php $products = json_decode($t['products'], true); ?>
            <tr>
              <td><?= $offset + $i + 1 ?></td>
              <td>
                <span class="sku" style="font-size:0.82rem;"><?= htmlspecialchars($t['kode']) ?></span>
              </td>
              <td>
                <div style="display:flex;align-items:center;gap:6px;">
                  <div class="user-avatar" style="width:24px;height:24px;font-size:11px;">
                    <?= strtoupper(substr($t['kasir_username'] ?? 'X', 0, 1)) ?>
                  </div>
                  <?= htmlspecialchars($t['kasir_username'] ?? 'Sistem') ?>
                </div>
              </td>
              <td>
                <div style="font-size:0.82rem;color:var(--brown-dark);">
                  <?= count($products) ?> item:
                  <?php $names = array_map(fn($p) => htmlspecialchars($p['name']), array_slice($products, 0, 2)); ?>
                  <?= implode(', ', $names) ?><?= count($products) > 2 ? '...' : '' ?>
                </div>
              </td>
              <td>
                <strong style="color:var(--brown-warm);">Rp <?= number_format($t['grand_total'], 0, ',', '.') ?></strong>
              </td>
              <td style="color:var(--brown-light);font-size:0.82rem;">
                <?= date('d M Y H:i', strtotime($t['created_at'])) ?>
              </td>
              <td>
                <button class="btn btn-primary btn-sm" onclick="viewDetail(<?= htmlspecialchars(json_encode($t)) ?>)">
                  🧾 Struk
                </button>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($total_pages > 1): ?>
      <div class="pagination">
        <?php for ($p2 = 1; $p2 <= $total_pages; $p2++): ?>
        <a href="?page=<?= $p2 ?>&search=<?= urlencode($search) ?>&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>"
           class="page-btn <?= $p2 == $page ? 'active' : '' ?>"><?= $p2 ?></a>
        <?php endfor; ?>
      </div>
      <div style="text-align:center;font-size:0.8rem;color:var(--brown-light);margin-top:4px;">
        Menampilkan <?= count($transactions) ?> dari <?= $total ?> transaksi
      </div>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Detail Modal -->
<div id="detailModal" class="modal-overlay">
  <div class="modal" style="max-width:460px;">
    <div class="modal-header">
      <span class="modal-title">🧾 Detail Transaksi</span>
      <button class="modal-close" onclick="closeModal('detailModal')">×</button>
    </div>
    <div class="modal-body" id="detailContent"></div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('detailModal')">Tutup</button>
      <button class="btn btn-primary" id="btnPrintReceipt" onclick="printDetailReceipt()">🖨️ Print Struk</button>
    </div>
  </div>
</div>

<script>
function applyFilter() {
  const s = document.getElementById('searchInput').value;
  const df = document.getElementById('dateFrom').value;
  const dt = document.getElementById('dateTo').value;
  window.location.href = `/transactions.php?search=${encodeURIComponent(s)}&date_from=${df}&date_to=${dt}`;
}

document.getElementById('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') applyFilter(); });

let currentTrx = null;

function viewDetail(trx) {
  currentTrx = trx;
  const products = JSON.parse(trx.products || '[]');
  let itemsHtml = products.map(item => {
    const price = item.price * (1 - (item.discount || 0) / 100);
    return `<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--cream-dark);font-size:0.875rem;">
      <div>
        <div style="font-weight:600;">${escHtml(item.name)}</div>
        <div style="font-size:0.75rem;color:var(--brown-light);">${item.qty} × ${formatRp(price)}${item.discount > 0 ? ` <span class="discount-tag">${item.discount}% off</span>` : ''}</div>
      </div>
      <div style="font-weight:700;white-space:nowrap;margin-left:12px;">${formatRp(price * item.qty)}</div>
    </div>`;
  }).join('');

  document.getElementById('detailContent').innerHTML = `
    <div style="background:var(--cream);border-radius:var(--radius);padding:12px 16px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <span style="font-size:0.78rem;color:var(--brown-light);">Kode Transaksi</span>
        <span style="font-family:var(--font-mono);font-weight:700;">${escHtml(trx.kode)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <span style="font-size:0.78rem;color:var(--brown-light);">Kasir</span>
        <span style="font-weight:600;">${escHtml(trx.kasir_username || 'Sistem')}</span>
      </div>
      <div style="display:flex;justify-content:space-between;">
        <span style="font-size:0.78rem;color:var(--brown-light);">Waktu</span>
        <span style="font-size:0.82rem;">${new Date(trx.created_at).toLocaleString('id-ID')}</span>
      </div>
    </div>
    <div style="margin-bottom:12px;">${itemsHtml}</div>
    <div style="display:flex;justify-content:space-between;padding:12px 0;border-top:2px solid var(--brown-pale);">
      <span style="font-family:var(--font-display);font-weight:700;font-size:1rem;">GRAND TOTAL</span>
      <span style="font-family:var(--font-display);font-weight:700;font-size:1.2rem;color:var(--brown-warm);">
        Rp ${Number(trx.grand_total).toLocaleString('id-ID')}
      </span>
    </div>`;

  openModal('detailModal');
}

function printDetailReceipt() {
  if (!currentTrx) return;
  const products = JSON.parse(currentTrx.products || '[]');
  let itemsHtml = products.map(item => {
    const price = item.price * (1 - (item.discount || 0) / 100);
    return `<div class="receipt-item">
      <div class="receipt-item-name">${escHtml(item.name)}<br><small>${item.qty}x @ ${formatRp(price)}</small></div>
      <div class="receipt-item-amount">${formatRp(price * item.qty)}</div>
    </div>`;
  }).join('');

  const w = window.open('', '_blank', 'width=400,height=600');
  w.document.write(`<!DOCTYPE html><html><head>
    <title>Struk ${currentTrx.kode}</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Courier New',monospace;font-size:12px;background:white;}
      .receipt-container{max-width:300px;margin:0 auto;padding:16px;}
      .receipt-header{text-align:center;margin-bottom:12px;}
      .receipt-header h1{font-size:18px;font-weight:bold;}
      .receipt-header p{font-size:11px;}
      hr{border:none;border-top:1px dashed #666;margin:8px 0;}
      .receipt-item{display:flex;justify-content:space-between;margin:3px 0;font-size:11px;}
      .receipt-item-name{flex:1;}
      .receipt-item-amount{text-align:right;white-space:nowrap;margin-left:8px;}
      .total-row{display:flex;justify-content:space-between;font-weight:bold;margin:3px 0;font-size:13px;}
      .receipt-footer{text-align:center;font-size:10px;color:#555;margin-top:12px;}
    </style>
  </head><body>
    <div class="receipt-container">
      <div class="receipt-header">
        <h1>ARIP STORE</h1>
        <p>Kardus Island</p>
        <p>Tel: +62 812-3456-7890</p>
      </div>
      <hr>
      <div style="display:flex;justify-content:space-between;font-size:10px;margin-bottom:8px;">
        <span>Kode: <strong>${currentTrx.kode}</strong></span>
        <span>${new Date(currentTrx.created_at).toLocaleString('id-ID')}</span>
      </div>
      <div style="font-size:10px;margin-bottom:8px;">Kasir: ${currentTrx.kasir_username || '-'}</div>
      <hr>
      ${itemsHtml}
      <hr>
      <div class="total-row">
        <span>TOTAL</span>
        <span>${formatRp(currentTrx.grand_total)}</span>
      </div>
      <hr>
      <div class="receipt-footer">
        <p>Terima kasih telah berbelanja!</p>
        <p>Selamat datang kembali</p>
      </div>
    </div>
    <script>window.onload=function(){window.print();window.close()}<\/script>
  </body></html>`);
  w.document.close();
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
