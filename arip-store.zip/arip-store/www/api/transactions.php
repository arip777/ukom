<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
  case 'GET':
    $id = intval($_GET['id'] ?? 0);
    if ($id) {
      $trx = db()->fetchOne(
        "SELECT t.*, k.username as kasir_username FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id WHERE t.id = ?",
        [$id]
      );
      if ($trx) {
        $trx['products'] = json_decode($trx['products'], true);
        echo json_encode(['success' => true, 'transaction' => $trx]);
      } else {
        echo json_encode(['success' => false, 'error' => 'Transaksi tidak ditemukan']);
      }
      exit;
    }
    $trxs = db()->fetchAll(
      "SELECT t.*, k.username as kasir_username FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id ORDER BY t.created_at DESC LIMIT 50"
    );
    echo json_encode(['success' => true, 'transactions' => $trxs]);
    break;

  case 'POST':
    $input = json_decode(file_get_contents('php://input'), true);
    $cartItems = $input['cart'] ?? [];
    $grand_total = floatval($input['grandTotal'] ?? 0);
    $kasir = getCurrentKasir();

    if (empty($cartItems)) {
      echo json_encode(['success' => false, 'error' => 'Keranjang kosong']);
      exit;
    }

    // Validate stock
    $pdo = db()->getConnection();
    $pdo->beginTransaction();

    try {
      $products_data = [];
      $computed_total = 0;

      foreach ($cartItems as $item) {
        $product = db()->fetchOne("SELECT * FROM produk WHERE id = ? FOR UPDATE", [intval($item['id'])]);
        if (!$product) {
          throw new Exception("Produk ID {$item['id']} tidak ditemukan");
        }
        if ($product['stock'] < $item['qty']) {
          throw new Exception("Stok {$product['name']} tidak mencukupi (stok: {$product['stock']})");
        }

        $price_after_discount = $product['price'] * (1 - $product['discount'] / 100);
        $subtotal = $price_after_discount * $item['qty'];
        $computed_total += $subtotal;

        $products_data[] = [
          'id' => $product['id'],
          'name' => $product['name'],
          'sku' => $product['sku'],
          'price' => floatval($product['price']),
          'discount' => floatval($product['discount']),
          'qty' => intval($item['qty']),
          'subtotal' => $subtotal,
        ];

        // Update stock
        db()->execute(
          "UPDATE produk SET stock = stock - ?, sold = sold + ? WHERE id = ?",
          [$item['qty'], $item['qty'], $product['id']]
        );
      }

      // Generate transaction code
      $kode = generateTransactionCode();
      // Ensure unique
      while (db()->fetchOne("SELECT id FROM transaksi WHERE kode = ?", [$kode])) {
        $kode = generateTransactionCode();
      }

      $trx_id = db()->insert(
        "INSERT INTO transaksi (kode, products, grand_total, kasir_id) VALUES (?,?,?,?)",
        [$kode, json_encode($products_data), $computed_total, $kasir['id']]
      );

      $pdo->commit();

      echo json_encode([
        'success' => true,
        'message' => 'Transaksi berhasil',
        'transaction' => [
          'id' => $trx_id,
          'kode' => $kode,
          'products' => $products_data,
          'grand_total' => $computed_total,
          'kasir_username' => $kasir['username'],
          'created_at' => date('Y-m-d H:i:s'),
        ]
      ]);
    } catch (Exception $e) {
      $pdo->rollBack();
      echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    break;

  default:
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
