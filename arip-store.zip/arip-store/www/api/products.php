<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
  case 'GET':
    $sku = trim($_GET['sku'] ?? '');
    $id = intval($_GET['id'] ?? 0);

    if ($sku) {
      $product = db()->fetchOne(
        "SELECT p.*, k.nama as kategori_nama, k.alias as kategori_alias
         FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id
         WHERE p.sku = ? LIMIT 1",
        [$sku]
      );
      if ($product) {
        echo json_encode(['success' => true, 'product' => $product]);
      } else {
        echo json_encode(['success' => false, 'error' => 'Produk tidak ditemukan']);
      }
      exit;
    }

    if ($id) {
      $product = db()->fetchOne("SELECT * FROM produk WHERE id = ?", [$id]);
      echo json_encode(['success' => true, 'product' => $product]);
      exit;
    }

    $products = db()->fetchAll(
      "SELECT p.*, k.nama as kategori_nama FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id ORDER BY p.name"
    );
    echo json_encode(['success' => true, 'products' => $products]);
    break;

  case 'POST':
    $input = json_decode(file_get_contents('php://input'), true);
    $name = trim($input['name'] ?? '');
    $kategori_id = $input['kategori_id'] ? intval($input['kategori_id']) : null;
    $price = floatval($input['price'] ?? 0);
    $berat = intval($input['berat'] ?? 0);
    $stock = intval($input['stock'] ?? 0);
    $discount = floatval($input['discount'] ?? 0);
    $sku = trim($input['sku'] ?? '');

    if (empty($name)) { echo json_encode(['success' => false, 'error' => 'Nama produk wajib diisi']); exit; }
    if ($price <= 0) { echo json_encode(['success' => false, 'error' => 'Harga harus lebih dari 0']); exit; }
    if (empty($sku)) {
      // Auto generate SKU
      if ($kategori_id) {
        $cat = db()->fetchOne("SELECT alias FROM kategori WHERE id = ?", [$kategori_id]);
        $alias = $cat ? $cat['alias'] : 'PRD';
      } else {
        $alias = 'PRD';
      }
      $nameSlug = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $name));
      $nameSlug = substr($nameSlug, 0, 12);
      $sku = "{$alias}-{$nameSlug}-{$berat}";
    }

    $sku = strtoupper($sku);
    $existing = db()->fetchOne("SELECT id FROM produk WHERE sku = ?", [$sku]);
    if ($existing) { echo json_encode(['success' => false, 'error' => 'SKU sudah digunakan']); exit; }

    $id = db()->insert(
      "INSERT INTO produk (name, sku, discount, kategori_id, berat, price, stock) VALUES (?,?,?,?,?,?,?)",
      [$name, $sku, $discount, $kategori_id, $berat, $price, $stock]
    );
    echo json_encode(['success' => true, 'message' => 'Produk berhasil ditambahkan', 'id' => $id]);
    break;

  case 'PUT':
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    $name = trim($input['name'] ?? '');
    $kategori_id = $input['kategori_id'] ? intval($input['kategori_id']) : null;
    $price = floatval($input['price'] ?? 0);
    $berat = intval($input['berat'] ?? 0);
    $stock = intval($input['stock'] ?? 0);
    $discount = floatval($input['discount'] ?? 0);
    $sku = strtoupper(trim($input['sku'] ?? ''));

    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID produk tidak valid']); exit; }
    if (empty($name)) { echo json_encode(['success' => false, 'error' => 'Nama produk wajib diisi']); exit; }

    $existing = db()->fetchOne("SELECT id FROM produk WHERE sku = ? AND id != ?", [$sku, $id]);
    if ($existing) { echo json_encode(['success' => false, 'error' => 'SKU sudah digunakan produk lain']); exit; }

    db()->execute(
      "UPDATE produk SET name=?, sku=?, discount=?, kategori_id=?, berat=?, price=?, stock=? WHERE id=?",
      [$name, $sku, $discount, $kategori_id, $berat, $price, $stock, $id]
    );
    echo json_encode(['success' => true, 'message' => 'Produk berhasil diperbarui']);
    break;

  case 'DELETE':
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID tidak valid']); exit; }
    db()->execute("DELETE FROM produk WHERE id = ?", [$id]);
    echo json_encode(['success' => true, 'message' => 'Produk berhasil dihapus']);
    break;

  default:
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
