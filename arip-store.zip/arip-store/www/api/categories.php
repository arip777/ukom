<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
  case 'GET':
    $categories = db()->fetchAll("SELECT * FROM kategori ORDER BY nama");
    echo json_encode(['success' => true, 'categories' => $categories]);
    break;

  case 'POST':
    $input = json_decode(file_get_contents('php://input'), true);
    $nama = trim($input['nama'] ?? '');
    $alias = strtoupper(trim($input['alias'] ?? ''));

    if (empty($nama)) { echo json_encode(['success' => false, 'error' => 'Nama kategori wajib diisi']); exit; }
    if (strlen($alias) !== 3 || !ctype_alpha($alias)) { echo json_encode(['success' => false, 'error' => 'Alias harus tepat 3 huruf']); exit; }

    $existing = db()->fetchOne("SELECT id FROM kategori WHERE alias = ?", [$alias]);
    if ($existing) { echo json_encode(['success' => false, 'error' => 'Alias sudah digunakan']); exit; }

    $id = db()->insert("INSERT INTO kategori (nama, alias) VALUES (?,?)", [$nama, $alias]);
    echo json_encode(['success' => true, 'message' => 'Kategori berhasil ditambahkan', 'id' => $id]);
    break;

  case 'PUT':
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    $nama = trim($input['nama'] ?? '');
    $alias = strtoupper(trim($input['alias'] ?? ''));

    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID tidak valid']); exit; }
    if (empty($nama)) { echo json_encode(['success' => false, 'error' => 'Nama wajib diisi']); exit; }
    if (strlen($alias) !== 3 || !ctype_alpha($alias)) { echo json_encode(['success' => false, 'error' => 'Alias harus tepat 3 huruf']); exit; }

    $existing = db()->fetchOne("SELECT id FROM kategori WHERE alias = ? AND id != ?", [$alias, $id]);
    if ($existing) { echo json_encode(['success' => false, 'error' => 'Alias sudah digunakan']); exit; }

    db()->execute("UPDATE kategori SET nama=?, alias=? WHERE id=?", [$nama, $alias, $id]);
    echo json_encode(['success' => true, 'message' => 'Kategori berhasil diperbarui']);
    break;

  case 'DELETE':
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID tidak valid']); exit; }
    // Check if category has products
    $count = db()->fetchOne("SELECT COUNT(*) as cnt FROM produk WHERE kategori_id = ?", [$id])['cnt'];
    if ($count > 0) {
      echo json_encode(['success' => false, 'error' => "Tidak bisa dihapus, ada $count produk yang menggunakan kategori ini"]);
      exit;
    }
    db()->execute("DELETE FROM kategori WHERE id = ?", [$id]);
    echo json_encode(['success' => true, 'message' => 'Kategori berhasil dihapus']);
    break;

  default:
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
