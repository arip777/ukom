CREATE DATABASE IF NOT EXISTS `arip_store` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `arip_store`;

-- Table: kasir
CREATE TABLE IF NOT EXISTS `kasir` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: kategori
CREATE TABLE IF NOT EXISTS `kategori` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `alias` CHAR(3) NOT NULL UNIQUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: produk
CREATE TABLE IF NOT EXISTS `produk` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `sku` VARCHAR(50) NOT NULL UNIQUE,
  `discount` DECIMAL(5,2) DEFAULT 0.00,
  `kategori_id` INT NULL,
  `berat` INT DEFAULT 0,
  `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `stock` INT DEFAULT 0,
  `sold` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`kategori_id`) REFERENCES `kategori`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: transaksi
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kode` VARCHAR(30) NOT NULL UNIQUE,
  `products` JSON NOT NULL,
  `grand_total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `kasir_id` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`kasir_id`) REFERENCES `kasir`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed data: kategori
INSERT INTO `kategori` (`nama`, `alias`) VALUES
('Minuman', 'MNM'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Sembako', 'SMB'),
('Kebersihan', 'KBR'),
('Rokok', 'ROK');

-- Seed data: produk
INSERT INTO `produk` (`name`, `sku`, `discount`, `kategori_id`, `berat`, `price`, `stock`, `sold`) VALUES
('Aqua Galon 19L', 'MNM-AQUAGALON-19000', 0, 1, 19000, 22000, 20, 45),
('Indomie Goreng', 'MKN-INDOMIEGORENG-85', 5, 2, 85, 3500, 100, 230),
('Chitato Rasa Sapi', 'SNK-CHITATOSAPI-68', 0, 3, 68, 15000, 50, 88),
('Beras Premium 5kg', 'SMB-BERASPREMIUM-5000', 0, 4, 5000, 75000, 30, 12),
('Sunlight Jeruk 200ml', 'KBR-SUNLIGHTJERUK-200', 10, 5, 200, 8500, 40, 67);

-- Default admin kasir (password: admin123)
INSERT INTO `kasir` (`username`, `email`, `password`) VALUES
('admin', 'admin@aripstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
