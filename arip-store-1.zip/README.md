# Arip Store POS

Point of Sale System untuk Minimarket  
**Lokasi:** Kardus Island  
**Tema:** YouTube Light Mode + Red Accent

---

## Stack
- PHP 7.2 (native, no framework, no PDO)
- MySQL 5.7
- Apache2 (Ubuntu 18.04)
- Vanilla JS

---

## Fitur
- 🔐 Auth (login / register) — identifikasi kasir
- 🛒 Kasir / POS — scan SKU, cart real-time, bayar, struk
- 📦 Manajemen Produk — CRUD, SKU otomatis, diskon, stok
- 🗂️ Manajemen Kategori — CRUD, alias 3 huruf untuk SKU
- 🧾 Riwayat Transaksi — filter, detail, cetak/download struk PDF
- 👥 Daftar Kasir (admin) — CRUD akun, reset password
- 👤 Profil — view & edit profil, ganti password (tab terpisah)

---

## Default Account
| Field    | Value           |
|----------|-----------------|
| Username | admin           |
| Password | admin123        |
| Email    | admin@admin.com |
| Role     | admin           |

---

## Cara Jalankan (Docker)

```bash
docker-compose up -d --build
```

- App  → http://localhost:8080
- phpMyAdmin → http://localhost:8081

### Stop
```bash
docker-compose down
```

### Reset database
```bash
docker-compose down -v
docker-compose up -d --build
```

---

## Cara Jalankan (XAMPP)

1. Copy folder `arip-store` ke `htdocs/`
2. Import `database.sql` ke phpMyAdmin
3. Edit `config.php` — sesuaikan `DB_HOST`, `DB_USER`, `DB_PASS` jika perlu
4. Akses: `http://localhost/arip-store`

---

## Format SKU

```
ALIAS-NAMAPRODUK-BERAT
```

Contoh:
- `MNM-AQUA-330` → Minuman / Aqua / 330g
- `MKN-INDOMIE-85` → Makanan / Indomie / 85g
- `SNK-CHITATO-68` → Snack / Chitato / 68g

---

## Struktur Direktori

```
arip-store/
├── config.php              ← Konfigurasi DB & helper
├── index.php               ← Dashboard
├── database.sql            ← SQL schema + seed data
├── Dockerfile
├── docker-compose.yml
├── assets/
│   └── css/style.css
├── includes/
│   ├── header.php
│   ├── footer.php
│   └── flash.php
└── pages/
    ├── auth/               ← login, register, logout
    ├── kasir/              ← POS interface
    ├── produk/             ← manajemen produk
    ├── kategori/           ← manajemen kategori
    ├── transaksi/          ← riwayat + struk
    ├── akun/               ← daftar kasir (admin)
    └── profile/            ← view & edit profil
```
