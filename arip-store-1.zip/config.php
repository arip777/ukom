<?php
// Arip Store POS - Config
define('APP_NAME', 'Arip Store');
define('APP_LOCATION', 'Kardus Island');
define('APP_VERSION', '1.0.0');

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'arip_store_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
define('BASE_URL', $protocol . '://' . $host);

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Database Connection
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die(json_encode(['error' => 'Database connection failed: ' . mysqli_connect_error()]));
        }
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn;
}

// Auth Helper
function isLoggedIn() {
    return isset($_SESSION['kasir_id']) && !empty($_SESSION['kasir_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/pages/auth/login.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $conn = getDB();
    $id = (int)$_SESSION['kasir_id'];
    $result = mysqli_query($conn, "SELECT * FROM kasir WHERE id = $id LIMIT 1");
    return mysqli_fetch_assoc($result);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Escape helper
function esc($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// Format currency
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Generate transaction code
function generateTrxCode() {
    $conn = getDB();
    $date = date('Ymd');
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM transaksi WHERE DATE(created_at) = CURDATE()");
    $row = mysqli_fetch_assoc($result);
    $seq = str_pad($row['total'] + 1, 4, '0', STR_PAD_LEFT);
    return "TRX-{$date}-{$seq}";
}

// Flash message
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
