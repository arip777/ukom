<?php
// includes/header.php
// Requires: $pageTitle (optional), $activePage (optional)
if (!isset($pageTitle)) $pageTitle = 'Arip Store POS';
if (!isset($activePage)) $activePage = '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($pageTitle) ?> - Arip Store</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <style>
        .material-symbols-rounded {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            vertical-align: middle;
            font-size: 22px;
        }
        .fill-icon { font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
    </style>
</head>
<body>

<?php
$user = getCurrentUser();
$firstLetter = $user ? strtoupper(substr($user['username'], 0, 1)) : 'A';
?>

<!-- HEADER -->
<header class="header">
    <button class="header-menu-btn" id="sidebarToggle" title="Toggle Sidebar">
        <span class="material-symbols-rounded">menu</span>
    </button>
    <a href="<?= BASE_URL ?>/index.php" class="header-logo">
        <div class="logo-icon">A</div>
        <span class="logo-text">Arip <span>Store</span></span>
    </a>
    <div class="header-spacer"></div>
    <div class="header-user" id="userMenuBtn">
        <div class="header-avatar"><?= $firstLetter ?></div>
        <span class="header-username"><?= esc($user['username'] ?? 'User') ?></span>
        <span class="material-symbols-rounded" style="font-size:18px;color:var(--yt-text-secondary)">expand_more</span>
        <div class="user-dropdown" id="userDropdown">
            <div class="dropdown-header">
                <div class="name"><?= esc($user['username'] ?? '') ?></div>
                <div class="email"><?= esc($user['email'] ?? '') ?></div>
            </div>
            <a href="<?= BASE_URL ?>/pages/profile/view.php" class="dropdown-item">
                <span class="material-symbols-rounded di-icon">account_circle</span> Profil Saya
            </a>
            <a href="<?= BASE_URL ?>/pages/profile/edit.php" class="dropdown-item">
                <span class="material-symbols-rounded di-icon">edit</span> Edit Profil
            </a>
            <a href="<?= BASE_URL ?>/pages/auth/logout.php" class="dropdown-item danger">
                <span class="material-symbols-rounded di-icon">logout</span> Keluar
            </a>
        </div>
    </div>
</header>

<!-- OVERLAY -->
<div class="overlay-bg" id="overlayBg"></div>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
    <div class="sidebar-section">
        <a href="<?= BASE_URL ?>/index.php" class="sidebar-item <?= $activePage === 'dashboard' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">dashboard</span>
            Dashboard
        </a>
        <a href="<?= BASE_URL ?>/pages/kasir/index.php" class="sidebar-item <?= $activePage === 'kasir' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">point_of_sale</span>
            Kasir / POS
        </a>
    </div>
    <div class="sidebar-divider"></div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">Manajemen</div>
        <a href="<?= BASE_URL ?>/pages/produk/index.php" class="sidebar-item <?= $activePage === 'produk' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">inventory_2</span>
            Produk
        </a>
        <a href="<?= BASE_URL ?>/pages/kategori/index.php" class="sidebar-item <?= $activePage === 'kategori' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">category</span>
            Kategori
        </a>
        <a href="<?= BASE_URL ?>/pages/transaksi/index.php" class="sidebar-item <?= $activePage === 'transaksi' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">receipt_long</span>
            Riwayat Transaksi
        </a>
    </div>
    <?php if (isAdmin()): ?>
    <div class="sidebar-divider"></div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">Admin</div>
        <a href="<?= BASE_URL ?>/pages/akun/index.php" class="sidebar-item <?= $activePage === 'akun' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">group</span>
            Daftar Kasir
        </a>
    </div>
    <?php endif; ?>
    <div class="sidebar-divider"></div>
    <div class="sidebar-section">
        <a href="<?= BASE_URL ?>/pages/profile/view.php" class="sidebar-item <?= $activePage === 'profile' ? 'active' : '' ?>">
            <span class="material-symbols-rounded si-icon">account_circle</span>
            Profil Saya
        </a>
        <a href="<?= BASE_URL ?>/pages/auth/logout.php" class="sidebar-item">
            <span class="material-symbols-rounded si-icon">logout</span>
            Keluar
        </a>
    </div>
</nav>

<!-- MAIN WRAPPER -->
<div class="main-wrapper" id="mainWrapper">
