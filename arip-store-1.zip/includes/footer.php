<?php // includes/footer.php ?>
</div><!-- end main-wrapper -->

<script>
(function() {
    // Sidebar toggle
    const sidebar = document.getElementById('sidebar');
    const mainWrapper = document.getElementById('mainWrapper');
    const overlayBg = document.getElementById('overlayBg');
    const sidebarToggle = document.getElementById('sidebarToggle');

    function isMobile() { return window.innerWidth <= 900; }

    function openSidebarMobile() {
        sidebar.classList.add('mobile-open');
        overlayBg.classList.add('show');
    }

    function closeSidebarMobile() {
        sidebar.classList.remove('mobile-open');
        overlayBg.classList.remove('show');
    }

    function toggleSidebarDesktop() {
        if (sidebar.classList.contains('collapsed')) {
            sidebar.classList.remove('collapsed');
            mainWrapper.classList.remove('sidebar-collapsed');
        } else {
            sidebar.classList.add('collapsed');
            mainWrapper.classList.add('sidebar-collapsed');
        }
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            if (isMobile()) {
                if (sidebar.classList.contains('mobile-open')) {
                    closeSidebarMobile();
                } else {
                    openSidebarMobile();
                }
            } else {
                toggleSidebarDesktop();
            }
        });
    }

    if (overlayBg) {
        overlayBg.addEventListener('click', closeSidebarMobile);
    }

    // User dropdown
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userDropdown = document.getElementById('userDropdown');

    if (userMenuBtn && userDropdown) {
        userMenuBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });

        document.addEventListener('click', function() {
            userDropdown.classList.remove('show');
        });
    }

    // Flash auto-hide
    const flashMsg = document.querySelector('.alert[data-auto-hide]');
    if (flashMsg) {
        setTimeout(function() {
            flashMsg.style.transition = 'opacity 0.4s';
            flashMsg.style.opacity = '0';
            setTimeout(function() { flashMsg.remove(); }, 400);
        }, 3500);
    }
})();
</script>
</body>
</html>
