<?php
// includes/flash.php
$flash = getFlash();
if ($flash):
    $icons = [
        'success' => 'check_circle',
        'danger'  => 'error',
        'warning' => 'warning',
        'info'    => 'info',
    ];
    $icon = $icons[$flash['type']] ?? 'info';
?>
<div class="alert alert-<?= esc($flash['type']) ?>" data-auto-hide>
    <span class="material-symbols-rounded fill-icon"><?= $icon ?></span>
    <?= esc($flash['message']) ?>
</div>
<?php endif; ?>
