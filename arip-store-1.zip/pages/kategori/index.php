<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Kategori';
$activePage = 'kategori';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $nama  = trim($_POST['nama'] ?? '');
        $alias = strtoupper(trim($_POST['alias'] ?? ''));

        if (empty($nama) || strlen($alias) !== 3) {
            setFlash('danger', 'Nama dan alias (tepat 3 karakter) wajib diisi.');
        } else {
            $n = mysqli_real_escape_string($conn, $nama);
            $a = mysqli_real_escape_string($conn, $alias);

            if ($action === 'add') {
                $check = mysqli_query($conn, "SELECT id FROM kategori WHERE alias = '$a' LIMIT 1");
                if (mysqli_num_rows($check) > 0) {
                    setFlash('danger', 'Alias sudah digunakan.');
                } else {
                    mysqli_query($conn, "INSERT INTO kategori (nama, alias) VALUES ('$n', '$a')");
                    setFlash('success', 'Kategori berhasil ditambahkan.');
                }
            } else {
                $id = (int)($_POST['id'] ?? 0);
                $check = mysqli_query($conn, "SELECT id FROM kategori WHERE alias = '$a' AND id != $id LIMIT 1");
                if (mysqli_num_rows($check) > 0) {
                    setFlash('danger', 'Alias sudah digunakan kategori lain.');
                } else {
                    mysqli_query($conn, "UPDATE kategori SET nama='$n', alias='$a' WHERE id=$id");
                    setFlash('success', 'Kategori berhasil diperbarui.');
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $check = mysqli_query($conn, "SELECT id FROM produk WHERE kategori_id = $id LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            setFlash('danger', 'Kategori tidak dapat dihapus karena masih memiliki produk.');
        } else {
            mysqli_query($conn, "DELETE FROM kategori WHERE id = $id");
            setFlash('success', 'Kategori berhasil dihapus.');
        }
    }
    header('Location: ' . BASE_URL . '/pages/kategori/index.php');
    exit;
}

$kategoriList = mysqli_query($conn, "
    SELECT k.*, COUNT(p.id) as total_produk
    FROM kategori k
    LEFT JOIN produk p ON p.kategori_id = k.id
    GROUP BY k.id
    ORDER BY k.nama ASC
");

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Manajemen Kategori</div>
            <div class="page-subtitle">Kelola kategori produk</div>
        </div>
        <button class="btn btn-primary" onclick="openModal('addModal')">
            <span class="material-symbols-rounded">add</span> Tambah Kategori
        </button>
    </div>

    <div class="card">
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Kategori</th>
                        <th>Alias (SKU Prefix)</th>
                        <th>Jumlah Produk</th>
                        <th>Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no = 1; while ($k = mysqli_fetch_assoc($kategoriList)): ?>
                <tr>
                    <td class="text-muted"><?= $no++ ?></td>
                    <td><div style="font-weight:500"><?= esc($k['nama']) ?></div></td>
                    <td><span class="sku-badge" style="font-size:13px;letter-spacing:1px"><?= esc($k['alias']) ?></span></td>
                    <td>
                        <span class="badge badge-blue"><?= $k['total_produk'] ?> produk</span>
                    </td>
                    <td class="text-muted" style="font-size:12px"><?= date('d/m/Y', strtotime($k['created_at'])) ?></td>
                    <td>
                        <div style="display:flex;gap:4px">
                            <button class="btn-icon" onclick="openEdit(<?= $k['id'] ?>, '<?= esc($k['nama']) ?>', '<?= esc($k['alias']) ?>')">
                                <span class="material-symbols-rounded">edit</span>
                            </button>
                            <button class="btn-icon danger" onclick="confirmDelete(<?= $k['id'] ?>, '<?= esc($k['nama']) ?>')">
                                <span class="material-symbols-rounded">delete</span>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Tambah Kategori</div>
            <button class="btn-icon" onclick="closeModal('addModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Kategori *</label>
                    <input type="text" name="nama" class="form-control" required placeholder="Contoh: Minuman">
                </div>
                <div class="form-group">
                    <label class="form-label">Alias SKU * (3 huruf)</label>
                    <input type="text" name="alias" class="form-control form-control-mono" required 
                        maxlength="3" minlength="3" placeholder="MNM" 
                        oninput="this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '')">
                    <div class="form-hint">Contoh: Minuman = MNM, Makanan = MKN. Digunakan sebagai prefix SKU.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Edit Kategori</div>
            <button class="btn-icon" onclick="closeModal('editModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Kategori *</label>
                    <input type="text" name="nama" id="editNama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias SKU * (3 huruf)</label>
                    <input type="text" name="alias" id="editAlias" class="form-control form-control-mono" required 
                        maxlength="3" minlength="3"
                        oninput="this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '')">
                    <div class="form-hint">Mengubah alias akan mempengaruhi format SKU produk baru di kategori ini.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('editModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirm -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal confirm-modal">
        <div class="modal-body">
            <div class="confirm-icon">🗂️</div>
            <div class="confirm-msg">Hapus kategori <strong id="deleteKatName"></strong>?</div>
        </div>
        <div class="modal-footer">
            <form method="POST" id="deleteForm">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteId">
                <button type="button" class="btn btn-outline" onclick="closeModal('deleteModal')">Batal</button>
                <button type="submit" class="btn btn-danger">Hapus</button>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(function(el) {
    el.addEventListener('click', function(e) { if (e.target === el) el.classList.remove('show'); });
});
function openEdit(id, nama, alias) {
    document.getElementById('editId').value = id;
    document.getElementById('editNama').value = nama;
    document.getElementById('editAlias').value = alias;
    openModal('editModal');
}
function confirmDelete(id, name) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteKatName').textContent = name;
    openModal('deleteModal');
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
