<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Riwayat Transaksi';
$activePage = 'transaksi';

// Filters
$search    = trim($_GET['search'] ?? '');
$dateFrom  = trim($_GET['date_from'] ?? '');
$dateTo    = trim($_GET['date_to'] ?? '');
$kasirFilter = (int)($_GET['kasir_id'] ?? 0);
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 15;
$offset    = ($page - 1) * $perPage;

$where = '1=1';
if ($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $where .= " AND (t.kode LIKE '%$s%' OR k.username LIKE '%$s%')";
}
if ($dateFrom) {
    $df = mysqli_real_escape_string($conn, $dateFrom);
    $where .= " AND DATE(t.created_at) >= '$df'";
}
if ($dateTo) {
    $dt = mysqli_real_escape_string($conn, $dateTo);
    $where .= " AND DATE(t.created_at) <= '$dt'";
}
if ($kasirFilter) {
    $where .= " AND t.kasir_id = $kasirFilter";
}

$total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM transaksi t JOIN kasir k ON k.id = t.kasir_id WHERE $where"))['total'];
$totalPages = ceil($total / $perPage);

$totalOmzet = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(t.grand_total),0) as total FROM transaksi t JOIN kasir k ON k.id = t.kasir_id WHERE $where"))['total'];

$trxList = mysqli_query($conn, "
    SELECT t.*, k.username 
    FROM transaksi t 
    JOIN kasir k ON k.id = t.kasir_id 
    WHERE $where
    ORDER BY t.created_at DESC 
    LIMIT $perPage OFFSET $offset
");

$kasirList = mysqli_query($conn, "SELECT id, username FROM kasir ORDER BY username ASC");

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Riwayat Transaksi</div>
            <div class="page-subtitle">Total <?= number_format($total) ?> transaksi &mdash; Omzet: <strong><?= formatRupiah($totalOmzet) ?></strong></div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card" style="margin-bottom:16px">
        <div class="card-body" style="padding:12px 16px">
            <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
                <div class="search-bar">
                    <span class="material-symbols-rounded search-icon">search</span>
                    <input type="text" name="search" class="form-control" placeholder="Cari kode / kasir..." value="<?= esc($search) ?>">
                </div>
                <div>
                    <label style="font-size:12px;font-weight:500;display:block;margin-bottom:4px">Dari</label>
                    <input type="date" name="date_from" class="form-control" value="<?= esc($dateFrom) ?>">
                </div>
                <div>
                    <label style="font-size:12px;font-weight:500;display:block;margin-bottom:4px">Sampai</label>
                    <input type="date" name="date_to" class="form-control" value="<?= esc($dateTo) ?>">
                </div>
                <?php if (isAdmin()): ?>
                <div>
                    <select name="kasir_id" class="form-control">
                        <option value="">Semua Kasir</option>
                        <?php while ($kas = mysqli_fetch_assoc($kasirList)): ?>
                        <option value="<?= $kas['id'] ?>" <?= $kasirFilter == $kas['id'] ? 'selected' : '' ?>>
                            <?= esc($kas['username']) ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-secondary"><span class="material-symbols-rounded">filter_list</span> Filter</button>
                <?php if ($search || $dateFrom || $dateTo || $kasirFilter): ?>
                <a href="<?= BASE_URL ?>/pages/transaksi/index.php" class="btn btn-outline">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Kode Transaksi</th>
                        <th>Kasir</th>
                        <th>Total Produk</th>
                        <th>Grand Total</th>
                        <th>Bayar</th>
                        <th>Kembalian</th>
                        <th>Waktu</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($trxList) === 0): ?>
                <tr>
                    <td colspan="9">
                        <div class="empty-state">
                            <div class="es-icon">🧾</div>
                            <h3>Tidak ada transaksi</h3>
                            <p>Belum ada transaksi yang sesuai filter</p>
                        </div>
                    </td>
                </tr>
                <?php else: $no = $offset + 1; while ($t = mysqli_fetch_assoc($trxList)):
                    $itemCount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c, SUM(qty) as q FROM transaksi_detail WHERE transaksi_id = " . (int)$t['id']));
                ?>
                <tr>
                    <td class="text-muted"><?= $no++ ?></td>
                    <td><span class="sku-badge"><?= esc($t['kode']) ?></span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:6px">
                            <div style="width:26px;height:26px;border-radius:50%;background:var(--yt-red);color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">
                                <?= strtoupper(substr($t['username'], 0, 1)) ?>
                            </div>
                            <?= esc($t['username']) ?>
                        </div>
                    </td>
                    <td><span class="badge badge-blue"><?= $itemCount['q'] ?> item (<?= $itemCount['c'] ?> jenis)</span></td>
                    <td class="fw-bold text-red"><?= formatRupiah($t['grand_total']) ?></td>
                    <td><?= formatRupiah($t['amount_paid']) ?></td>
                    <td class="text-success fw-bold"><?= formatRupiah($t['change_amount']) ?></td>
                    <td>
                        <div style="font-size:12px"><?= date('d/m/Y', strtotime($t['created_at'])) ?></div>
                        <div style="font-size:11px;color:var(--yt-text-secondary)"><?= date('H:i:s', strtotime($t['created_at'])) ?></div>
                    </td>
                    <td>
                        <div style="display:flex;gap:4px">
                            <button class="btn btn-sm btn-outline" onclick="openDetail(<?= $t['id'] ?>)">
                                <span class="material-symbols-rounded" style="font-size:16px">visibility</span>
                            </button>
                            <a href="<?= BASE_URL ?>/pages/transaksi/struk.php?id=<?= $t['id'] ?>" target="_blank" class="btn btn-sm btn-secondary">
                                <span class="material-symbols-rounded" style="font-size:16px">print</span>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php
            $queryStr = http_build_query(['search' => $search, 'date_from' => $dateFrom, 'date_to' => $dateTo, 'kasir_id' => $kasirFilter ?: '']);
            ?>
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&<?= $queryStr ?>" class="page-btn">
                <span class="material-symbols-rounded" style="font-size:18px">chevron_left</span>
            </a>
            <?php endif; ?>
            <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
            <a href="?page=<?= $i ?>&<?= $queryStr ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&<?= $queryStr ?>" class="page-btn">
                <span class="material-symbols-rounded" style="font-size:18px">chevron_right</span>
            </a>
            <?php endif; ?>
            <span class="pagination-info"><?= $offset+1 ?>-<?= min($offset+$perPage, $total) ?> dari <?= number_format($total) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Detail Modal -->
<div class="modal-overlay" id="detailModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">Detail Transaksi</div>
            <button class="btn-icon" onclick="closeModal('detailModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <div class="modal-body" id="detailContent">
            <div style="text-align:center;padding:24px"><div class="spinner"></div></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeModal('detailModal')">Tutup</button>
            <a href="#" id="detailStrukLink" target="_blank" class="btn btn-primary">
                <span class="material-symbols-rounded">print</span> Cetak Struk
            </a>
        </div>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(function(el) {
    el.addEventListener('click', function(e) { if (e.target === el) el.classList.remove('show'); });
});

function openDetail(id) {
    document.getElementById('detailContent').innerHTML = '<div style="text-align:center;padding:24px"><div class="spinner"></div></div>';
    document.getElementById('detailStrukLink').href = '<?= BASE_URL ?>/pages/transaksi/struk.php?id=' + id;
    openModal('detailModal');

    fetch('<?= BASE_URL ?>/pages/transaksi/detail_ajax.php?id=' + id)
        .then(function(r) { return r.text(); })
        .then(function(html) {
            document.getElementById('detailContent').innerHTML = html;
        });
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
