<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$id = (int)($_GET['id'] ?? 0);

$trx = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT t.*, k.username 
    FROM transaksi t 
    JOIN kasir k ON k.id = t.kasir_id 
    WHERE t.id = $id LIMIT 1
"));

if (!$trx) { echo '<div class="alert alert-danger">Transaksi tidak ditemukan</div>'; exit; }

$details = mysqli_query($conn, "SELECT * FROM transaksi_detail WHERE transaksi_id = $id ORDER BY id ASC");
?>
<div style="margin-bottom:16px">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="detail-info-grid">
        <div>
            <div style="font-size:12px;color:var(--yt-text-secondary)">Kode Transaksi</div>
            <div style="font-family:'Roboto Mono',monospace;font-weight:700;font-size:16px"><?= esc($trx['kode']) ?></div>
        </div>
        <div>
            <div style="font-size:12px;color:var(--yt-text-secondary)">Kasir</div>
            <div style="font-weight:600"><?= esc($trx['username']) ?></div>
        </div>
        <div>
            <div style="font-size:12px;color:var(--yt-text-secondary)">Waktu</div>
            <div><?= date('d M Y H:i:s', strtotime($trx['created_at'])) ?></div>
        </div>
    </div>
</div>

<div style="margin-bottom:16px">
    <div style="font-size:13px;font-weight:600;color:var(--yt-text-secondary);margin-bottom:8px;text-transform:uppercase;letter-spacing:0.5px">Produk</div>
    <div class="table-wrapper" style="border:1px solid var(--yt-border);border-radius:8px;overflow:hidden">
        <table class="table" style="font-size:13px">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>SKU</th>
                    <th>Harga</th>
                    <th>Disc</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($d = mysqli_fetch_assoc($details)): ?>
            <tr>
                <td><?= esc($d['produk_name']) ?></td>
                <td><span class="sku-badge"><?= esc($d['produk_sku']) ?></span></td>
                <td><?= formatRupiah($d['price']) ?></td>
                <td><?= $d['discount'] > 0 ? $d['discount'].'%' : '-' ?></td>
                <td><?= $d['qty'] ?></td>
                <td class="fw-bold"><?= formatRupiah($d['subtotal']) ?></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div style="background:var(--yt-hover);border-radius:8px;padding:16px">
    <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:14px">
        <span>Grand Total</span>
        <span class="fw-bold text-red" style="font-size:18px"><?= formatRupiah($trx['grand_total']) ?></span>
    </div>
    <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px;color:var(--yt-text-secondary)">
        <span>Uang Diterima</span>
        <span><?= formatRupiah($trx['amount_paid']) ?></span>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:13px">
        <span>Kembalian</span>
        <span class="text-success fw-bold"><?= formatRupiah($trx['change_amount']) ?></span>
    </div>
</div>

<style>
@media (max-width:500px) { .detail-info-grid { grid-template-columns: 1fr !important; } }
</style>
