<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$id = (int)($_GET['id'] ?? 0);

$trx = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT t.*, k.username 
    FROM transaksi t 
    JOIN kasir k ON k.id = t.kasir_id 
    WHERE t.id = $id LIMIT 1
"));

if (!$trx) {
    die('Transaksi tidak ditemukan.');
}

$details = [];
$res = mysqli_query($conn, "SELECT * FROM transaksi_detail WHERE transaksi_id = $id ORDER BY id ASC");
while ($d = mysqli_fetch_assoc($res)) $details[] = $d;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk <?= esc($trx['kode']) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <style>
        .material-symbols-rounded { font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24; vertical-align:middle; font-size:22px; }
        body { background: #f5f5f5; }
        .struk-page { padding: 24px; display: flex; flex-direction: column; align-items: center; gap: 16px; }
        .struk-actions { display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; }
        @media print {
            .struk-actions { display: none !important; }
            body { background: white; }
            .struk-page { padding: 0; }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>
<body>
<div class="struk-page">
    <div class="struk-actions no-print">
        <button class="btn btn-primary" onclick="window.print()">
            <span class="material-symbols-rounded">print</span> Print Struk
        </button>
        <button class="btn btn-secondary" onclick="downloadPDF()">
            <span class="material-symbols-rounded">download</span> Download PDF
        </button>
        <a href="javascript:history.back()" class="btn btn-outline">
            <span class="material-symbols-rounded">arrow_back</span> Kembali
        </a>
    </div>

    <div class="struk-container" id="strukEl" style="border:1px dashed #ccc;box-shadow:0 2px 12px rgba(0,0,0,0.08)">
        <div class="struk-header">
            <h2><?= APP_NAME ?></h2>
            <p><?= APP_LOCATION ?></p>
            <p>Kasir: <?= esc($trx['username']) ?></p>
        </div>
        <hr class="struk-divider">
        <div style="font-size:11px;margin-bottom:8px">
            <div>Kode: <strong><?= esc($trx['kode']) ?></strong></div>
            <div>Waktu: <?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></div>
        </div>
        <hr class="struk-divider">

        <?php foreach ($details as $d): 
            $finalPrice = $d['price'] - ($d['price'] * $d['discount'] / 100);
        ?>
        <div class="struk-item">
            <span class="name"><?= esc($d['produk_name']) ?></span>
        </div>
        <div class="struk-item" style="padding-left:8px">
            <span><?= $d['qty'] ?> x <?= number_format($finalPrice, 0, ',', '.') ?></span>
            <span class="amount"><?= number_format($d['subtotal'], 0, ',', '.') ?></span>
        </div>
        <?php if ($d['discount'] > 0): ?>
        <div style="font-size:10px;padding-left:8px;color:#777">Diskon <?= $d['discount'] ?>%</div>
        <?php endif; ?>
        <?php endforeach; ?>

        <hr class="struk-divider">
        <div class="struk-total">
            <div class="struk-item">
                <span>TOTAL</span>
                <span class="amount"><strong><?= 'Rp ' . number_format($trx['grand_total'], 0, ',', '.') ?></strong></span>
            </div>
            <div class="struk-item">
                <span>Bayar</span>
                <span class="amount"><?= 'Rp ' . number_format($trx['amount_paid'], 0, ',', '.') ?></span>
            </div>
            <div class="struk-item">
                <span>Kembalian</span>
                <span class="amount"><?= 'Rp ' . number_format($trx['change_amount'], 0, ',', '.') ?></span>
            </div>
        </div>
        <hr class="struk-divider">
        <div class="struk-footer">
            <p>Terima kasih telah berbelanja!</p>
            <p><?= APP_NAME ?> - <?= APP_LOCATION ?></p>
            <p style="margin-top:8px;font-size:10px"><?= date('d/m/Y H:i:s', strtotime($trx['created_at'])) ?></p>
        </div>
    </div>
</div>

<script>
function downloadPDF() {
    var btn = event.target.closest('button');
    btn.disabled = true;
    btn.textContent = 'Mengunduh...';

    // Use browser print to PDF approach
    window.print();
    
    btn.disabled = false;
    btn.innerHTML = '<span class="material-symbols-rounded">download</span> Download PDF';
}
</script>
</body>
</html>
