<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Produk';
$activePage = 'produk';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name       = trim($_POST['name'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);
        $berat      = (int)($_POST['berat'] ?? 0);
        $price      = (float)($_POST['price'] ?? 0);
        $discount   = (float)($_POST['discount'] ?? 0);
        $stock      = (int)($_POST['stock'] ?? 0);

        if (empty($name) || !$kategori_id || !$price) {
            setFlash('danger', 'Nama, kategori, dan harga wajib diisi.');
        } else {
            // Get kategori alias
            $katRes = mysqli_query($conn, "SELECT alias FROM kategori WHERE id = $kategori_id LIMIT 1");
            $katRow = mysqli_fetch_assoc($katRes);
            if (!$katRow) {
                setFlash('danger', 'Kategori tidak valid.');
            } else {
                $alias = $katRow['alias'];
                // Build SKU: ALIAS-NAME_SLUG-BERAT
                $nameSlug = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $name));
                $nameSlug = substr($nameSlug, 0, 10);
                $sku = $alias . '-' . $nameSlug . '-' . $berat;

                $n = mysqli_real_escape_string($conn, $name);
                $s = mysqli_real_escape_string($conn, $sku);
                $d = (float)$discount;

                if ($action === 'add') {
                    $check = mysqli_query($conn, "SELECT id FROM produk WHERE sku = '$s' LIMIT 1");
                    if (mysqli_num_rows($check) > 0) {
                        // Append timestamp suffix
                        $sku .= '-' . date('is');
                        $s = mysqli_real_escape_string($conn, $sku);
                    }
                    mysqli_query($conn, "INSERT INTO produk (name, sku, kategori_id, berat, price, discount, stock) VALUES ('$n', '$s', $kategori_id, $berat, $price, $d, $stock)");
                    setFlash('success', 'Produk berhasil ditambahkan. SKU: ' . $sku);
                } else {
                    $id = (int)($_POST['id'] ?? 0);
                    // Check SKU conflict (exclude self)
                    $check = mysqli_query($conn, "SELECT id FROM produk WHERE sku = '$s' AND id != $id LIMIT 1");
                    if (mysqli_num_rows($check) > 0) {
                        setFlash('danger', 'SKU sudah digunakan produk lain.');
                    } else {
                        // Allow custom SKU if user provided
                        $customSku = trim($_POST['sku'] ?? '');
                        if (!empty($customSku)) {
                            $s = mysqli_real_escape_string($conn, strtoupper($customSku));
                        }
                        mysqli_query($conn, "UPDATE produk SET name='$n', sku='$s', kategori_id=$kategori_id, berat=$berat, price=$price, discount=$d, stock=$stock WHERE id=$id");
                        setFlash('success', 'Produk berhasil diperbarui.');
                    }
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // Check if used in transactions
        $check = mysqli_query($conn, "SELECT id FROM transaksi_detail WHERE produk_id = $id LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            setFlash('danger', 'Produk tidak dapat dihapus karena sudah memiliki riwayat transaksi.');
        } else {
            mysqli_query($conn, "DELETE FROM produk WHERE id = $id");
            setFlash('success', 'Produk berhasil dihapus.');
        }
    }
    header('Location: ' . BASE_URL . '/pages/produk/index.php');
    exit;
}

// Filters & Pagination
$search = trim($_GET['search'] ?? '');
$kategoriFilter = (int)($_GET['kategori'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$where = '1=1';
if ($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $where .= " AND (p.name LIKE '%$s%' OR p.sku LIKE '%$s%')";
}
if ($kategoriFilter) {
    $where .= " AND p.kategori_id = $kategoriFilter";
}

$total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM produk p WHERE $where"))['total'];
$totalPages = ceil($total / $perPage);

$produkList = mysqli_query($conn, "
    SELECT p.*, k.nama as kategori_nama 
    FROM produk p 
    JOIN kategori k ON k.id = p.kategori_id
    WHERE $where 
    ORDER BY p.name ASC 
    LIMIT $perPage OFFSET $offset
");

$kategoriList = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama ASC");
$kategoriArr = [];
while ($k = mysqli_fetch_assoc($kategoriList)) $kategoriArr[] = $k;

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Manajemen Produk</div>
            <div class="page-subtitle">Total <?= number_format($total) ?> produk</div>
        </div>
        <button class="btn btn-primary" onclick="openModal('addModal')">
            <span class="material-symbols-rounded">add</span> Tambah Produk
        </button>
    </div>

    <!-- Filters -->
    <div class="card" style="margin-bottom:16px">
        <div class="card-body" style="padding:12px 16px">
            <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
                <div class="search-bar" style="max-width:280px">
                    <span class="material-symbols-rounded search-icon">search</span>
                    <input type="text" name="search" class="form-control" placeholder="Cari nama / SKU..." value="<?= esc($search) ?>">
                </div>
                <div>
                    <select name="kategori" class="form-control" style="min-width:160px">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($kategoriArr as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= $kategoriFilter == $k['id'] ? 'selected' : '' ?>>
                            <?= esc($k['nama']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-secondary"><span class="material-symbols-rounded">filter_list</span> Filter</button>
                <?php if ($search || $kategoriFilter): ?>
                <a href="<?= BASE_URL ?>/pages/produk/index.php" class="btn btn-outline">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Produk</th>
                        <th>SKU</th>
                        <th>Kategori</th>
                        <th>Berat</th>
                        <th>Harga</th>
                        <th>Diskon</th>
                        <th>Stok</th>
                        <th>Terjual</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($produkList) === 0): ?>
                <tr>
                    <td colspan="10">
                        <div class="empty-state">
                            <div class="es-icon">📦</div>
                            <h3>Tidak ada produk</h3>
                            <p>Tambah produk baru untuk mulai berjualan</p>
                        </div>
                    </td>
                </tr>
                <?php else: $no = $offset + 1; while ($p = mysqli_fetch_assoc($produkList)): ?>
                <tr>
                    <td class="text-muted"><?= $no++ ?></td>
                    <td>
                        <div style="font-weight:500"><?= esc($p['name']) ?></div>
                    </td>
                    <td><span class="sku-badge"><?= esc($p['sku']) ?></span></td>
                    <td><?= esc($p['kategori_nama']) ?></td>
                    <td class="text-muted"><?= number_format($p['berat']) ?> g</td>
                    <td class="fw-bold"><?= formatRupiah($p['price']) ?></td>
                    <td>
                        <?php if ($p['discount'] > 0): ?>
                        <span class="badge badge-green"><?= $p['discount'] ?>%</span>
                        <?php else: ?>
                        <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?= $p['stock'] == 0 ? 'badge-red' : ($p['stock'] <= 10 ? 'badge-orange' : 'badge-green') ?>">
                            <?= number_format($p['stock']) ?>
                        </span>
                    </td>
                    <td><?= number_format($p['sold']) ?></td>
                    <td>
                        <div style="display:flex;gap:4px">
                            <button class="btn-icon" title="Edit" onclick="openEdit(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">
                                <span class="material-symbols-rounded">edit</span>
                            </button>
                            <button class="btn-icon danger" title="Hapus" onclick="confirmDelete(<?= $p['id'] ?>, '<?= esc($p['name']) ?>')">
                                <span class="material-symbols-rounded">delete</span>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php
            $queryStr = http_build_query(['search' => $search, 'kategori' => $kategoriFilter ?: '']);
            ?>
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&<?= $queryStr ?>" class="page-btn">
                <span class="material-symbols-rounded" style="font-size:18px">chevron_left</span>
            </a>
            <?php else: ?>
            <span class="page-btn disabled"><span class="material-symbols-rounded" style="font-size:18px">chevron_left</span></span>
            <?php endif; ?>

            <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
            <a href="?page=<?= $i ?>&<?= $queryStr ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&<?= $queryStr ?>" class="page-btn">
                <span class="material-symbols-rounded" style="font-size:18px">chevron_right</span>
            </a>
            <?php endif; ?>

            <span class="pagination-info"><?= $offset+1 ?>-<?= min($offset+$perPage, $total) ?> dari <?= number_format($total) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">Tambah Produk</div>
            <button class="btn-icon" onclick="closeModal('addModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nama Produk *</label>
                        <input type="text" name="name" class="form-control" required placeholder="Contoh: Aqua Botol">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori_id" class="form-control" required onchange="previewSKU()">
                            <option value="">Pilih kategori</option>
                            <?php foreach ($kategoriArr as $k): ?>
                            <option value="<?= $k['id'] ?>" data-alias="<?= esc($k['alias']) ?>"><?= esc($k['nama']) ?> (<?= esc($k['alias']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Berat (gram) *</label>
                        <div class="input-group input-group-suffix">
                            <input type="number" name="berat" id="addBerat" class="form-control" required placeholder="0" min="0" oninput="previewSKU()">
                            <span class="input-suffix">gram</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">SKU (otomatis)</label>
                        <input type="text" id="skuPreview" class="form-control form-control-mono" readonly 
                            style="background:var(--yt-hover);color:var(--yt-text-secondary)" placeholder="Pilih kategori & isi berat">
                        <div class="form-hint">Format: ALIAS-NAMAPRODUK-BERAT</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Harga *</label>
                        <div class="input-group">
                            <span class="input-addon">Rp</span>
                            <input type="number" name="price" class="form-control" required placeholder="0" min="0" step="100">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <div class="input-group input-group-suffix">
                            <input type="number" name="discount" class="form-control" value="0" min="0" max="100" step="0.01">
                            <span class="input-suffix">%</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Stok Awal</label>
                    <input type="number" name="stock" class="form-control" value="0" min="0">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">Edit Produk</div>
            <button class="btn-icon" onclick="closeModal('editModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nama Produk *</label>
                        <input type="text" name="name" id="editName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori_id" id="editKategori" class="form-control" required>
                            <?php foreach ($kategoriArr as $k): ?>
                            <option value="<?= $k['id'] ?>"><?= esc($k['nama']) ?> (<?= esc($k['alias']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Berat (gram)</label>
                        <div class="input-group input-group-suffix">
                            <input type="number" name="berat" id="editBerat" class="form-control" min="0">
                            <span class="input-suffix">gram</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">SKU</label>
                        <input type="text" name="sku" id="editSku" class="form-control form-control-mono">
                        <div class="form-hint">Edit manual jika diperlukan</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Harga *</label>
                        <div class="input-group">
                            <span class="input-addon">Rp</span>
                            <input type="number" name="price" id="editPrice" class="form-control" required min="0" step="100">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <div class="input-group input-group-suffix">
                            <input type="number" name="discount" id="editDiscount" class="form-control" min="0" max="100" step="0.01">
                            <span class="input-suffix">%</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stock" id="editStock" class="form-control" min="0">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('editModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirm -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal confirm-modal">
        <div class="modal-body">
            <div class="confirm-icon">🗑️</div>
            <div class="confirm-msg">Hapus produk <strong id="deleteName"></strong>?<br>
            <small class="text-muted">Produk yang sudah pernah bertransaksi tidak dapat dihapus.</small></div>
        </div>
        <div class="modal-footer">
            <form method="POST" id="deleteForm">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteId">
                <button type="button" class="btn btn-outline" onclick="closeModal('deleteModal')">Batal</button>
                <button type="submit" class="btn btn-danger"><span class="material-symbols-rounded">delete</span> Hapus</button>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(function(el) {
    el.addEventListener('click', function(e) { if (e.target === el) el.classList.remove('show'); });
});

function openEdit(p) {
    document.getElementById('editId').value = p.id;
    document.getElementById('editName').value = p.name;
    document.getElementById('editKategori').value = p.kategori_id;
    document.getElementById('editBerat').value = p.berat;
    document.getElementById('editSku').value = p.sku;
    document.getElementById('editPrice').value = p.price;
    document.getElementById('editDiscount').value = p.discount;
    document.getElementById('editStock').value = p.stock;
    openModal('editModal');
}

function confirmDelete(id, name) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteName').textContent = name;
    openModal('deleteModal');
}

// SKU Preview for Add
function previewSKU() {
    var selKat = document.querySelector('#addModal select[name="kategori_id"]');
    var berat = document.getElementById('addBerat').value;
    var nameInput = document.querySelector('#addModal input[name="name"]');
    
    if (!selKat || !selKat.value) { document.getElementById('skuPreview').value = ''; return; }
    var alias = selKat.options[selKat.selectedIndex].dataset.alias || '';
    var name = (nameInput ? nameInput.value : '').toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 10);
    if (alias && name && berat) {
        document.getElementById('skuPreview').value = alias + '-' + name + '-' + berat;
    }
}

document.querySelector('#addModal input[name="name"]') && document.querySelector('#addModal input[name="name"]').addEventListener('input', previewSKU);
document.querySelector('#addModal select[name="kategori_id"]') && document.querySelector('#addModal select[name="kategori_id"]').addEventListener('change', previewSKU);
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
