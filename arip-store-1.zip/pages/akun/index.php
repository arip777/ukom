<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Daftar Kasir';
$activePage = 'akun';

if (!isAdmin()) {
    setFlash('danger', 'Akses ditolak. Hanya admin yang dapat mengakses halaman ini.');
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role     = in_array($_POST['role'] ?? '', ['admin', 'kasir']) ? $_POST['role'] : 'kasir';

        if (empty($username) || empty($email) || empty($password)) {
            setFlash('danger', 'Semua field wajib diisi.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            setFlash('danger', 'Format email tidak valid.');
        } elseif (strlen($password) < 6) {
            setFlash('danger', 'Password minimal 6 karakter.');
        } else {
            $u = mysqli_real_escape_string($conn, $username);
            $e = mysqli_real_escape_string($conn, $email);
            $check = mysqli_query($conn, "SELECT id FROM kasir WHERE username='$u' OR email='$e' LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                setFlash('danger', 'Username atau email sudah digunakan.');
            } else {
                $hash = mysqli_real_escape_string($conn, password_hash($password, PASSWORD_BCRYPT));
                $r = mysqli_real_escape_string($conn, $role);
                mysqli_query($conn, "INSERT INTO kasir (username, email, password, role) VALUES ('$u', '$e', '$hash', '$r')");
                setFlash('success', 'Akun kasir berhasil ditambahkan.');
            }
        }
    } elseif ($action === 'edit') {
        $id       = (int)($_POST['id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $role     = in_array($_POST['role'] ?? '', ['admin', 'kasir']) ? $_POST['role'] : 'kasir';
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($email)) {
            setFlash('danger', 'Username dan email wajib diisi.');
        } else {
            $u = mysqli_real_escape_string($conn, $username);
            $e = mysqli_real_escape_string($conn, $email);
            $r = mysqli_real_escape_string($conn, $role);
            $check = mysqli_query($conn, "SELECT id FROM kasir WHERE (username='$u' OR email='$e') AND id != $id LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                setFlash('danger', 'Username atau email sudah digunakan.');
            } else {
                if (!empty($password) && strlen($password) >= 6) {
                    $hash = mysqli_real_escape_string($conn, password_hash($password, PASSWORD_BCRYPT));
                    mysqli_query($conn, "UPDATE kasir SET username='$u', email='$e', role='$r', password='$hash' WHERE id=$id");
                } else {
                    mysqli_query($conn, "UPDATE kasir SET username='$u', email='$e', role='$r' WHERE id=$id");
                }
                setFlash('success', 'Akun berhasil diperbarui.');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === (int)$_SESSION['kasir_id']) {
            setFlash('danger', 'Tidak dapat menghapus akun sendiri.');
        } else {
            $check = mysqli_query($conn, "SELECT id FROM transaksi WHERE kasir_id = $id LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                setFlash('danger', 'Akun tidak dapat dihapus karena memiliki riwayat transaksi.');
            } else {
                mysqli_query($conn, "DELETE FROM kasir WHERE id = $id");
                setFlash('success', 'Akun berhasil dihapus.');
            }
        }
    } elseif ($action === 'reset_password') {
        $id = (int)($_POST['id'] ?? 0);
        $newPw = trim($_POST['new_password'] ?? '');
        if (strlen($newPw) < 6) {
            setFlash('danger', 'Password minimal 6 karakter.');
        } else {
            $hash = mysqli_real_escape_string($conn, password_hash($newPw, PASSWORD_BCRYPT));
            mysqli_query($conn, "UPDATE kasir SET password='$hash' WHERE id=$id");
            setFlash('success', 'Password berhasil direset.');
        }
    }
    header('Location: ' . BASE_URL . '/pages/akun/index.php');
    exit;
}

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset  = ($page - 1) * $perPage;
$search  = trim($_GET['search'] ?? '');
$where   = '1=1';
if ($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $where .= " AND (username LIKE '%$s%' OR email LIKE '%$s%')";
}

$total     = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM kasir WHERE $where"))['total'];
$totalPages = ceil($total / $perPage);

$kasirList = mysqli_query($conn, "
    SELECT k.*, 
        (SELECT COUNT(*) FROM transaksi t WHERE t.kasir_id = k.id) as total_trx,
        (SELECT COALESCE(SUM(grand_total),0) FROM transaksi t WHERE t.kasir_id = k.id) as total_omzet
    FROM kasir k WHERE $where
    ORDER BY k.created_at DESC 
    LIMIT $perPage OFFSET $offset
");

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Daftar Kasir</div>
            <div class="page-subtitle">Total <?= number_format($total) ?> akun terdaftar</div>
        </div>
        <button class="btn btn-primary" onclick="openModal('addModal')">
            <span class="material-symbols-rounded">person_add</span> Tambah Kasir
        </button>
    </div>

    <!-- Search -->
    <div class="card" style="margin-bottom:16px">
        <div class="card-body" style="padding:12px 16px">
            <form method="GET" style="display:flex;gap:10px">
                <div class="search-bar flex-1" style="max-width:320px">
                    <span class="material-symbols-rounded search-icon">search</span>
                    <input type="text" name="search" class="form-control" placeholder="Cari username / email..." value="<?= esc($search) ?>">
                </div>
                <button type="submit" class="btn btn-secondary"><span class="material-symbols-rounded">search</span> Cari</button>
                <?php if ($search): ?>
                <a href="<?= BASE_URL ?>/pages/akun/index.php" class="btn btn-outline">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Transaksi</th>
                        <th>Total Omzet</th>
                        <th>Bergabung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($kasirList) === 0): ?>
                <tr><td colspan="8"><div class="empty-state"><div class="es-icon">👥</div><h3>Tidak ada data</h3></div></td></tr>
                <?php else: $no = $offset + 1; while ($k = mysqli_fetch_assoc($kasirList)): ?>
                <tr>
                    <td class="text-muted"><?= $no++ ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px">
                            <div style="width:32px;height:32px;border-radius:50%;background:<?= $k['role'] === 'admin' ? 'var(--yt-red)' : '#065FD4' ?>;color:white;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0">
                                <?= strtoupper(substr($k['username'], 0, 1)) ?>
                            </div>
                            <div>
                                <div style="font-weight:600"><?= esc($k['username']) ?></div>
                                <?php if ($k['id'] == $_SESSION['kasir_id']): ?>
                                <div style="font-size:10px;color:var(--yt-text-secondary)">(Anda)</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td class="text-muted"><?= esc($k['email']) ?></td>
                    <td>
                        <span class="badge <?= $k['role'] === 'admin' ? 'badge-red' : 'badge-blue' ?>">
                            <?= $k['role'] === 'admin' ? 'Admin' : 'Kasir' ?>
                        </span>
                    </td>
                    <td><?= number_format($k['total_trx']) ?> trx</td>
                    <td class="fw-bold"><?= formatRupiah($k['total_omzet']) ?></td>
                    <td style="font-size:12px;color:var(--yt-text-secondary)"><?= date('d/m/Y', strtotime($k['created_at'])) ?></td>
                    <td>
                        <div style="display:flex;gap:4px">
                            <button class="btn-icon" title="Edit" onclick="openEdit(<?= htmlspecialchars(json_encode(['id'=>$k['id'],'username'=>$k['username'],'email'=>$k['email'],'role'=>$k['role']]), ENT_QUOTES) ?>)">
                                <span class="material-symbols-rounded">edit</span>
                            </button>
                            <button class="btn-icon" title="Reset Password" onclick="openResetPw(<?= $k['id'] ?>, '<?= esc($k['username']) ?>')">
                                <span class="material-symbols-rounded">lock_reset</span>
                            </button>
                            <?php if ($k['id'] != $_SESSION['kasir_id']): ?>
                            <button class="btn-icon danger" title="Hapus" onclick="confirmDelete(<?= $k['id'] ?>, '<?= esc($k['username']) ?>')">
                                <span class="material-symbols-rounded">delete</span>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <span class="pagination-info"><?= $offset+1 ?>-<?= min($offset+$perPage, $total) ?> dari <?= number_format($total) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Tambah Kasir</div>
            <button class="btn-icon" onclick="closeModal('addModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-control" required minlength="6" placeholder="Minimal 6 karakter">
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-control">
                        <option value="kasir">Kasir</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Edit Kasir</div>
            <button class="btn-icon" onclick="closeModal('editModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" id="editUsername" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" id="editEmail" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" id="editRole" class="form-control">
                        <option value="kasir">Kasir</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Password Baru (kosongkan jika tidak diubah)</label>
                    <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('editModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">save</span> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal-overlay" id="resetPwModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Reset Password</div>
            <button class="btn-icon" onclick="closeModal('resetPwModal')"><span class="material-symbols-rounded">close</span></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="id" id="resetPwId">
            <div class="modal-body">
                <p style="margin-bottom:12px;font-size:13px">Reset password untuk akun: <strong id="resetPwUsername"></strong></p>
                <div class="form-group">
                    <label class="form-label">Password Baru *</label>
                    <input type="password" name="new_password" class="form-control" required minlength="6" placeholder="Minimal 6 karakter">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('resetPwModal')">Batal</button>
                <button type="submit" class="btn btn-primary"><span class="material-symbols-rounded">lock_reset</span> Reset</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal confirm-modal">
        <div class="modal-body">
            <div class="confirm-icon">👤</div>
            <div class="confirm-msg">Hapus akun <strong id="deleteUsername"></strong>?</div>
        </div>
        <div class="modal-footer">
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteId">
                <button type="button" class="btn btn-outline" onclick="closeModal('deleteModal')">Batal</button>
                <button type="submit" class="btn btn-danger">Hapus</button>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(function(el) {
    el.addEventListener('click', function(e) { if (e.target === el) el.classList.remove('show'); });
});
function openEdit(d) {
    document.getElementById('editId').value = d.id;
    document.getElementById('editUsername').value = d.username;
    document.getElementById('editEmail').value = d.email;
    document.getElementById('editRole').value = d.role;
    openModal('editModal');
}
function openResetPw(id, name) {
    document.getElementById('resetPwId').value = id;
    document.getElementById('resetPwUsername').textContent = name;
    openModal('resetPwModal');
}
function confirmDelete(id, name) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteUsername').textContent = name;
    openModal('deleteModal');
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
