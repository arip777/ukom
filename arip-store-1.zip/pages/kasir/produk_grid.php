<?php
require_once __DIR__ . '/../../config.php';
requireLogin();
header('Content-Type: application/json');

$conn = getDB();

// Return kategori list
if (isset($_GET['action']) && $_GET['action'] === 'kategori') {
    $result = mysqli_query($conn, "SELECT id, nama FROM kategori ORDER BY nama ASC");
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) $data[] = $row;
    echo json_encode($data);
    exit;
}

// Return produk grid
$where = 'p.stock > 0';
if (!empty($_GET['kategori'])) {
    $kid = (int)$_GET['kategori'];
    $where .= " AND p.kategori_id = $kid";
}

$result = mysqli_query($conn, "
    SELECT p.id, p.name, p.sku, p.price, p.discount, p.stock, p.kategori_id, k.nama as kategori
    FROM produk p 
    JOIN kategori k ON k.id = p.kategori_id
    WHERE $where
    ORDER BY p.name ASC
    LIMIT 60
");

$data = [];
while ($row = mysqli_fetch_assoc($result)) $data[] = $row;
echo json_encode($data);
