<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Kasir';
$activePage = 'kasir';

// Handle SKU search (AJAX)
if (isset($_GET['action']) && $_GET['action'] === 'search_sku') {
    header('Content-Type: application/json');
    $q = mysqli_real_escape_string($conn, trim($_GET['q'] ?? ''));
    if (strlen($q) < 1) { echo json_encode([]); exit; }
    $result = mysqli_query($conn, "
        SELECT p.id, p.name, p.sku, p.price, p.discount, p.stock, k.nama as kategori
        FROM produk p JOIN kategori k ON k.id = p.kategori_id
        WHERE (p.sku LIKE '$q%' OR p.name LIKE '%$q%') AND p.stock > 0
        ORDER BY p.sku ASC LIMIT 10
    ");
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}

// Handle GET product by SKU (AJAX)
if (isset($_GET['action']) && $_GET['action'] === 'get_by_sku') {
    header('Content-Type: application/json');
    $sku = mysqli_real_escape_string($conn, trim($_GET['sku'] ?? ''));
    $result = mysqli_query($conn, "
        SELECT p.id, p.name, p.sku, p.price, p.discount, p.stock, k.nama as kategori
        FROM produk p JOIN kategori k ON k.id = p.kategori_id
        WHERE p.sku = '$sku' LIMIT 1
    ");
    $prod = mysqli_fetch_assoc($result);
    if ($prod) {
        echo json_encode(['success' => true, 'product' => $prod]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan']);
    }
    exit;
}

// Handle checkout (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    header('Content-Type: application/json');
    $items = json_decode($_POST['items'] ?? '[]', true);
    $amountPaid = (float)($_POST['amount_paid'] ?? 0);

    if (empty($items)) {
        echo json_encode(['success' => false, 'message' => 'Keranjang kosong']);
        exit;
    }

    $grandTotal = 0;
    foreach ($items as $item) {
        $price = (float)$item['price'];
        $discount = (float)$item['discount'];
        $qty = (int)$item['qty'];
        $discountedPrice = $price - ($price * $discount / 100);
        $grandTotal += $discountedPrice * $qty;
    }

    if ($amountPaid < $grandTotal) {
        echo json_encode(['success' => false, 'message' => 'Uang tidak cukup']);
        exit;
    }

    $changeAmount = $amountPaid - $grandTotal;
    $kode = generateTrxCode();
    $kasirId = (int)$_SESSION['kasir_id'];
    $gt = round($grandTotal, 2);
    $ap = round($amountPaid, 2);
    $ca = round($changeAmount, 2);
    $k = mysqli_real_escape_string($conn, $kode);

    mysqli_begin_transaction($conn);
    try {
        mysqli_query($conn, "INSERT INTO transaksi (kode, kasir_id, grand_total, amount_paid, change_amount) VALUES ('$k', $kasirId, $gt, $ap, $ca)");
        $trxId = mysqli_insert_id($conn);

        foreach ($items as $item) {
            $pid = (int)$item['id'];
            $pname = mysqli_real_escape_string($conn, $item['name']);
            $psku = mysqli_real_escape_string($conn, $item['sku']);
            $qty = (int)$item['qty'];
            $price = (float)$item['price'];
            $discount = (float)$item['discount'];
            $discountedPrice = $price - ($price * $discount / 100);
            $subtotal = round($discountedPrice * $qty, 2);

            // Check stock
            $stockRes = mysqli_query($conn, "SELECT stock FROM produk WHERE id = $pid LIMIT 1");
            $stockRow = mysqli_fetch_assoc($stockRes);
            if (!$stockRow || $stockRow['stock'] < $qty) {
                throw new Exception("Stok produk '{$item['name']}' tidak cukup");
            }

            mysqli_query($conn, "INSERT INTO transaksi_detail (transaksi_id, produk_id, produk_name, produk_sku, qty, price, discount, subtotal) 
                VALUES ($trxId, $pid, '$pname', '$psku', $qty, $price, $discount, $subtotal)");
            mysqli_query($conn, "UPDATE produk SET stock = stock - $qty, sold = sold + $qty WHERE id = $pid");
        }

        mysqli_commit($conn);
        echo json_encode(['success' => true, 'trx_id' => $trxId, 'kode' => $kode, 'grand_total' => $gt, 'change' => $ca]);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container" style="max-width:100%">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Kasir / POS</div>
            <div class="page-subtitle">Scan atau cari produk menggunakan SKU</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
            <span class="badge badge-green" style="font-size:13px;padding:6px 12px">
                <span class="material-symbols-rounded fill-icon" style="font-size:16px">person</span>
                &nbsp;<?= esc($_SESSION['username'] ?? '') ?>
            </span>
        </div>
    </div>

    <div class="kasir-layout">
        <!-- LEFT: Product Search -->
        <div class="kasir-left">
            <!-- SKU Input -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <span class="material-symbols-rounded" style="color:var(--yt-red)">qr_code_scanner</span>
                        Cari Produk
                    </div>
                </div>
                <div class="card-body">
                    <div style="position:relative">
                        <div class="input-group">
                            <span class="input-addon"><span class="material-symbols-rounded">barcode_scanner</span></span>
                            <input type="text" id="skuInput" class="form-control form-control-mono" 
                                placeholder="Scan / ketik SKU atau nama produk..." 
                                autocomplete="off" autocorrect="off" spellcheck="false">
                            <button class="btn btn-primary" onclick="addBySKU()">
                                <span class="material-symbols-rounded">add</span> Tambah
                            </button>
                        </div>
                        <div class="product-search-result" id="searchResults"></div>
                    </div>
                    <div class="form-hint mt-1">Tekan Enter untuk menambah produk. Format SKU: KATEGORI-NAMA-BERAT</div>
                </div>
            </div>

            <!-- Products Grid (quick access - last 20 with stock) -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Produk Tersedia</div>
                    <div id="filterChips" class="filter-chips" style="margin-bottom:0"></div>
                </div>
                <div id="produkGrid" style="padding:16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;max-height:380px;overflow-y:auto;">
                    <div style="grid-column:1/-1;text-align:center;padding:20px;color:var(--yt-text-secondary)">
                        <div class="spinner"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT: Cart -->
        <div class="card cart-card" id="cartCard">
            <div class="card-header">
                <div class="card-title">
                    <span class="material-symbols-rounded fill-icon" style="color:var(--yt-red)">shopping_cart</span>
                    Keranjang
                </div>
                <div style="display:flex;gap:6px;align-items:center">
                    <span class="badge badge-red" id="cartCountBadge">0 item</span>
                    <button class="btn-icon danger" onclick="clearCart()" title="Kosongkan keranjang">
                        <span class="material-symbols-rounded">delete_sweep</span>
                    </button>
                    <button class="btn-icon cart-close-btn" onclick="closeMobileCart()" title="Tutup">
                        <span class="material-symbols-rounded">keyboard_arrow_down</span>
                    </button>
                </div>
            </div>
            <!-- Empty state kept OUTSIDE cartItems so innerHTML overwrite doesn't break it -->
            <div class="cart-empty" id="cartEmpty">
                <div class="ce-icon">🛒</div>
                <p>Keranjang masih kosong<br>Scan produk untuk mulai</p>
            </div>
            <!-- Cart item rows rendered here safely -->
            <div id="cartItems" class="cart-items" style="display:none"></div>
            <div class="cart-footer" id="cartFooter" style="display:none">
                <div class="cart-total-row">
                    <span>Subtotal</span>
                    <span id="footerSubtotal">Rp 0</span>
                </div>
                <div class="cart-total-row">
                    <span>Diskon</span>
                    <span id="footerDiscount" style="color:var(--success)">- Rp 0</span>
                </div>
                <div class="cart-total-row grand">
                    <span>TOTAL</span>
                    <span id="footerTotal">Rp 0</span>
                </div>
                <button class="btn btn-primary" style="width:100%;justify-content:center;margin-top:12px;padding:12px;font-size:15px" onclick="openPayment()">
                    <span class="material-symbols-rounded">payments</span> Bayar Sekarang
                </button>
                <button class="btn btn-outline" style="width:100%;justify-content:center;margin-top:8px" onclick="clearCart()">
                    <span class="material-symbols-rounded">remove_shopping_cart</span> Kosongkan
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Cart FAB for mobile -->
<button class="cart-fab" id="cartFab" onclick="toggleMobileCart()">
    <span class="material-symbols-rounded fill-icon">shopping_cart</span>
    <span id="fabTotal">Rp 0</span>
    <div class="cart-fab-badge" id="fabCount">0</div>
</button>

<!-- Mobile cart backdrop -->
<div id="cartMobileOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.45);z-index:799;display:none" onclick="closeMobileCart()"></div>
<style>
#cartMobileOverlay.show { display:block; }
</style>

<!-- Payment Modal -->
<div class="modal-overlay" id="paymentModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">
                <span class="material-symbols-rounded" style="color:var(--yt-red)">payments</span>
                Pembayaran
            </div>
            <button class="btn-icon" onclick="closeModal('paymentModal')">
                <span class="material-symbols-rounded">close</span>
            </button>
        </div>
        <div class="modal-body">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px" class="pay-grid">
                <!-- Summary -->
                <div>
                    <div style="font-size:13px;font-weight:600;color:var(--yt-text-secondary);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.5px">Ringkasan Belanja</div>
                    <div id="paymentItems"></div>
                    <div class="payment-item total">
                        <span>TOTAL BAYAR</span>
                        <span id="payTotalDisplay">Rp 0</span>
                    </div>
                </div>
                <!-- Payment Input -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Uang Diterima (Rp)</label>
                        <input type="number" id="amountPaid" class="form-control" style="font-size:20px;font-weight:700;text-align:right" 
                            placeholder="0" min="0" oninput="calcChange()" onkeydown="if(event.key==='Enter')processPayment()">
                    </div>
                    <div class="nominal-grid" id="nominalGrid"></div>
                    <div class="change-display" id="changeDisplay" style="display:none">
                        <div class="change-label">Kembalian</div>
                        <div class="change-value" id="changeValue">Rp 0</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeModal('paymentModal')">Batal</button>
            <button class="btn btn-success" onclick="processPayment()" id="payBtn">
                <span class="material-symbols-rounded">check_circle</span> Proses Pembayaran
            </button>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal-overlay" id="successModal">
    <div class="modal" style="max-width:400px">
        <div class="modal-body" style="text-align:center;padding:32px">
            <div style="font-size:64px;margin-bottom:8px">✅</div>
            <h2 style="font-size:20px;font-weight:700;margin-bottom:8px">Transaksi Berhasil!</h2>
            <p style="color:var(--yt-text-secondary);font-size:14px;margin-bottom:4px" id="successKode"></p>
            <p style="font-size:24px;font-weight:700;color:var(--yt-red);margin:8px 0" id="successTotal"></p>
            <div class="change-display" style="margin-bottom:16px">
                <div class="change-label">Kembalian</div>
                <div class="change-value" id="successChange"></div>
            </div>
            <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
                <button class="btn btn-outline" onclick="window.open('<?= BASE_URL ?>/pages/transaksi/struk.php?id='+lastTrxId,'_blank')">
                    <span class="material-symbols-rounded">print</span> Cetak Struk
                </button>
                <button class="btn btn-primary" onclick="newTransaction()">
                    <span class="material-symbols-rounded">add_circle</span> Transaksi Baru
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// ===================== CART STATE =====================
var cart = {}; // {id: {id, name, sku, price, discount, qty, stock}}
var lastTrxId = 0;

function formatRp(n) {
    return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// ===================== PRODUCT SEARCH =====================
var searchTimeout = null;
var searchEl = document.getElementById('skuInput');
var resultsEl = document.getElementById('searchResults');

searchEl.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    var q = this.value.trim();
    if (q.length < 1) { hideResults(); return; }
    searchTimeout = setTimeout(function() { searchProducts(q); }, 200);
});

searchEl.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        addBySKU();
    }
});

function searchProducts(q) {
    fetch('<?= BASE_URL ?>/pages/kasir/index.php?action=search_sku&q=' + encodeURIComponent(q))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.length === 0) { hideResults(); return; }
            var html = '';
            data.forEach(function(p) {
                var discPrice = p.price - (p.price * p.discount / 100);
                html += '<div class="search-result-item" onclick="addProductToCart(' + JSON.stringify(p).replace(/"/g, '&quot;') + ')">';
                html += '<div><div class="sr-name">' + esc(p.name) + '</div>';
                html += '<div class="sr-sku">' + esc(p.sku) + ' &bull; Stok: ' + p.stock + '</div></div>';
                html += '<div class="sr-price">' + formatRp(discPrice) + '</div>';
                html += '</div>';
            });
            resultsEl.innerHTML = html;
            resultsEl.classList.add('show');
        });
}

function hideResults() {
    resultsEl.classList.remove('show');
    resultsEl.innerHTML = '';
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('#skuInput') && !e.target.closest('#searchResults')) {
        hideResults();
    }
});

function esc(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ===================== ADD BY SKU =====================
function addBySKU() {
    var sku = searchEl.value.trim();
    if (!sku) return;
    hideResults();

    fetch('<?= BASE_URL ?>/pages/kasir/index.php?action=get_by_sku&sku=' + encodeURIComponent(sku))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.success) {
                addProductToCart(data.product);
            } else {
                showToast('Produk tidak ditemukan: ' + sku, 'danger');
            }
        });
}

// ===================== CART FUNCTIONS =====================
function addProductToCart(product) {
    var id = String(product.id);
    searchEl.value = '';
    hideResults();
    searchEl.focus();

    if (cart[id]) {
        if (cart[id].qty >= parseInt(product.stock)) {
            showToast('Stok tidak cukup!', 'warning');
            return;
        }
        cart[id].qty++;
    } else {
        cart[id] = {
            id: product.id,
            name: product.name,
            sku: product.sku,
            price: parseFloat(product.price),
            discount: parseFloat(product.discount),
            qty: 1,
            stock: parseInt(product.stock)
        };
    }
    renderCart();
    showToast(product.name + ' ditambahkan', 'success');
}

function updateQty(id, delta) {
    id = String(id);
    if (!cart[id]) return;
    cart[id].qty += delta;
    if (cart[id].qty <= 0) {
        delete cart[id];
    } else if (cart[id].qty > cart[id].stock) {
        cart[id].qty = cart[id].stock;
        showToast('Stok maksimal ' + cart[id].stock, 'warning');
    }
    renderCart();
}

function removeFromCart(id) {
    delete cart[String(id)];
    renderCart();
}

function clearCart() {
    if (Object.keys(cart).length === 0) return;
    if (!confirm('Kosongkan keranjang?')) return;
    cart = {};
    renderCart();
}

function renderCart() {
    var ids = Object.keys(cart);
    var countEl    = document.getElementById('cartCountBadge');
    var emptyEl    = document.getElementById('cartEmpty');
    var footerEl   = document.getElementById('cartFooter');
    var itemsEl    = document.getElementById('cartItems');
    var fabCountEl = document.getElementById('fabCount');
    var fabTotalEl = document.getElementById('fabTotal');

    if (ids.length === 0) {
        // Show empty state, hide items list & footer
        emptyEl.style.display  = '';
        itemsEl.style.display  = 'none';
        footerEl.style.display = 'none';
        itemsEl.innerHTML      = '';
        countEl.textContent    = '0 item';
        fabCountEl.textContent = '0';
        fabTotalEl.textContent = 'Rp 0';
        return;
    }

    // Has items: hide empty state, show items list & footer
    emptyEl.style.display  = 'none';
    itemsEl.style.display  = '';
    footerEl.style.display = '';

    var html = '';
    var subtotal = 0, totalDisc = 0;

    ids.forEach(function(id) {
        var item     = cart[id];
        var discAmt  = item.price * item.discount / 100;
        var finalPrice = item.price - discAmt;
        var lineTotal  = finalPrice * item.qty;
        subtotal  += item.price * item.qty;
        totalDisc += discAmt * item.qty;

        html += '<div class="cart-item">';
        html += '<div class="cart-item-info">';
        html += '<div class="cart-item-name">' + esc(item.name) + '</div>';
        html += '<div class="cart-item-price">' + formatRp(finalPrice);
        if (item.discount > 0) html += ' <span style="color:var(--success);font-size:11px">(-' + item.discount + '%)</span>';
        html += '</div></div>';
        html += '<div class="qty-ctrl">';
        html += '<button class="qty-btn" onclick="updateQty(\'' + id + '\', -1)">&#8722;</button>';
        html += '<span class="qty-display">' + item.qty + '</span>';
        html += '<button class="qty-btn" onclick="updateQty(\'' + id + '\', 1)">&#43;</button>';
        html += '</div>';
        html += '<div class="cart-subtotal">' + formatRp(lineTotal) + '</div>';
        html += '<button class="btn-icon danger" onclick="removeFromCart(\'' + id + '\')" style="margin-left:4px;">';
        html += '<span class="material-symbols-rounded" style="font-size:18px">close</span></button>';
        html += '</div>';
    });

    itemsEl.innerHTML = html;

    var grand    = subtotal - totalDisc;
    var totalQty = ids.reduce(function(acc, id) { return acc + cart[id].qty; }, 0);

    document.getElementById('footerSubtotal').textContent  = formatRp(subtotal);
    document.getElementById('footerDiscount').textContent  = '- ' + formatRp(totalDisc);
    document.getElementById('footerTotal').textContent     = formatRp(grand);
    countEl.textContent    = totalQty + ' item';
    fabCountEl.textContent = totalQty;
    fabTotalEl.textContent = formatRp(grand);
}

// ===================== PAYMENT =====================
function openPayment() {
    var ids = Object.keys(cart);
    if (ids.length === 0) { showToast('Keranjang kosong!', 'warning'); return; }

    var grand = 0, html = '';
    ids.forEach(function(id) {
        var item = cart[id];
        var finalPrice = item.price - (item.price * item.discount / 100);
        var lineTotal = finalPrice * item.qty;
        grand += lineTotal;
        html += '<div class="payment-item"><span>' + esc(item.name) + ' x' + item.qty + '</span><span>' + formatRp(lineTotal) + '</span></div>';
    });

    document.getElementById('paymentItems').innerHTML = html;
    document.getElementById('payTotalDisplay').textContent = formatRp(grand);
    document.getElementById('amountPaid').value = '';
    document.getElementById('changeDisplay').style.display = 'none';

    // Nominal buttons
    var nominals = [grand, 5000, 10000, 20000, 50000, 100000];
    // Smart nominals based on total
    if (grand > 100000) nominals = [grand, 100000, 150000, 200000, 500000, 1000000];
    else if (grand > 50000) nominals = [grand, 50000, 100000, 150000, 200000, 500000];
    else if (grand > 20000) nominals = [grand, 20000, 50000, 100000, 150000, 200000];

    var nbHtml = '';
    nominals.forEach(function(n) {
        nbHtml += '<button class="nominal-btn" onclick="setNominal(' + n + ')">' + formatRp(n) + '</button>';
    });
    document.getElementById('nominalGrid').innerHTML = nbHtml;

    openModal('paymentModal');
    setTimeout(function() { document.getElementById('amountPaid').focus(); }, 300);
}

function setNominal(n) {
    document.getElementById('amountPaid').value = n;
    calcChange();
}

function calcChange() {
    var grand = getGrandTotal();
    var paid = parseFloat(document.getElementById('amountPaid').value) || 0;
    var changeEl = document.getElementById('changeDisplay');
    var changeVal = document.getElementById('changeValue');
    var payBtn = document.getElementById('payBtn');

    if (paid > 0) {
        changeEl.style.display = '';
        var change = paid - grand;
        changeVal.textContent = formatRp(Math.max(0, change));
        changeVal.style.color = change >= 0 ? 'var(--success)' : 'var(--danger)';
        payBtn.disabled = change < 0;
    } else {
        changeEl.style.display = 'none';
        payBtn.disabled = false;
    }
}

function getGrandTotal() {
    var grand = 0;
    Object.keys(cart).forEach(function(id) {
        var item = cart[id];
        var finalPrice = item.price - (item.price * item.discount / 100);
        grand += finalPrice * item.qty;
    });
    return grand;
}

function processPayment() {
    var amountPaid = parseFloat(document.getElementById('amountPaid').value) || 0;
    var grand = getGrandTotal();
    if (amountPaid < grand) { showToast('Uang tidak cukup!', 'danger'); return; }

    var items = Object.values(cart);
    var payBtn = document.getElementById('payBtn');
    payBtn.disabled = true;
    payBtn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-width:2px"></div> Memproses...';

    var formData = new FormData();
    formData.append('action', 'checkout');
    formData.append('items', JSON.stringify(items));
    formData.append('amount_paid', amountPaid);

    fetch('<?= BASE_URL ?>/pages/kasir/index.php', { method: 'POST', body: formData })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            payBtn.disabled = false;
            payBtn.innerHTML = '<span class="material-symbols-rounded">check_circle</span> Proses Pembayaran';

            if (data.success) {
                lastTrxId = data.trx_id;
                closeModal('paymentModal');
                document.getElementById('successKode').textContent = 'Kode: ' + data.kode;
                document.getElementById('successTotal').textContent = formatRp(data.grand_total);
                document.getElementById('successChange').textContent = formatRp(data.change);
                openModal('successModal');
                cart = {};
                renderCart();
            } else {
                showToast(data.message || 'Terjadi kesalahan', 'danger');
            }
        })
        .catch(function() {
            payBtn.disabled = false;
            payBtn.innerHTML = '<span class="material-symbols-rounded">check_circle</span> Proses Pembayaran';
            showToast('Koneksi gagal, coba lagi', 'danger');
        });
}

function newTransaction() {
    closeModal('successModal');
    cart = {};
    renderCart();
    searchEl.focus();
}

// ===================== PRODUCT GRID =====================
function loadProdukGrid(kategoriId) {
    var grid = document.getElementById('produkGrid');
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:20px"><div class="spinner"></div></div>';
    
    var url = '<?= BASE_URL ?>/pages/kasir/produk_grid.php?stock=1';
    if (kategoriId) url += '&kategori=' + kategoriId;
    
    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.length) {
                grid.innerHTML = '<div style="grid-column:1/-1" class="empty-state"><div class="es-icon">📦</div><h3>Tidak ada produk</h3></div>';
                return;
            }
            var html = '';
            data.forEach(function(p) {
                var finalPrice = p.price - (p.price * p.discount / 100);
                html += '<div class="produk-tile" onclick="addProductToCart(' + JSON.stringify(p).replace(/"/g, '&quot;') + ')" title="' + esc(p.sku) + '">';
                html += '<div class="pt-name">' + esc(p.name) + '</div>';
                html += '<div class="pt-sku">' + esc(p.sku) + '</div>';
                html += '<div class="pt-price">' + formatRp(finalPrice) + '</div>';
                if (p.discount > 0) html += '<div class="pt-disc">Diskon ' + p.discount + '%</div>';
                html += '<div class="pt-stock">Stok: ' + p.stock + '</div>';
                html += '</div>';
            });
            grid.innerHTML = html;
        });
}

function loadKategoriChips() {
    fetch('<?= BASE_URL ?>/pages/kasir/produk_grid.php?action=kategori')
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var html = '<div class="chip active-red" onclick="filterKategori(this, 0)">Semua</div>';
            data.forEach(function(k) {
                html += '<div class="chip" onclick="filterKategori(this, ' + k.id + ')">' + esc(k.nama) + '</div>';
            });
            document.getElementById('filterChips').innerHTML = html;
        });
}

function filterKategori(el, id) {
    document.querySelectorAll('#filterChips .chip').forEach(function(c) { c.className = 'chip'; });
    el.className = 'chip active-red';
    loadProdukGrid(id || null);
}

// ===================== MODAL HELPERS =====================
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }

document.querySelectorAll('.modal-overlay').forEach(function(el) {
    el.addEventListener('click', function(e) {
        if (e.target === el) el.classList.remove('show');
    });
});

// ===================== MOBILE CART =====================
function toggleMobileCart() {
    var card = document.getElementById('cartCard');
    if (card.classList.contains('mobile-show')) {
        closeMobileCart();
    } else {
        openMobileCart();
    }
}

function openMobileCart() {
    var card = document.getElementById('cartCard');
    card.classList.add('mobile-show');
    document.getElementById('cartMobileOverlay').classList.add('show');
}

function closeMobileCart() {
    var card = document.getElementById('cartCard');
    card.classList.remove('mobile-show');
    document.getElementById('cartMobileOverlay').classList.remove('show');
}

// ===================== TOAST =====================
function showToast(msg, type) {
    var existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    
    var colors = { success: '#1DB954', danger: '#FF0000', warning: '#FF9500', info: '#065FD4' };
    var icons = { success: 'check_circle', danger: 'error', warning: 'warning', info: 'info' };
    
    var el = document.createElement('div');
    el.className = 'toast-msg';
    el.style.cssText = 'position:fixed;top:70px;right:16px;background:white;border:1px solid #E5E5E5;border-left:4px solid ' + (colors[type]||'#FF0000') + ';border-radius:8px;padding:10px 14px;font-size:13px;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.1);display:flex;align-items:center;gap:8px;max-width:320px;animation:slideIn 0.2s ease';
    el.innerHTML = '<span class="material-symbols-rounded fill-icon" style="color:' + (colors[type]||'#FF0000') + ';font-size:18px">' + (icons[type]||'info') + '</span>' + esc(msg);
    document.body.appendChild(el);
    setTimeout(function() { if (el.parentNode) el.remove(); }, 2800);
}

// ===================== INIT =====================
document.addEventListener('DOMContentLoaded', function() {
    renderCart();
    loadKategoriChips();
    loadProdukGrid(null);
    searchEl.focus();
});
</script>

<style>
.produk-tile {
    background: var(--yt-white);
    border: 1px solid var(--yt-border);
    border-radius: 10px;
    padding: 12px;
    cursor: pointer;
    transition: all 0.15s;
    min-height: 90px;
}
.produk-tile:hover {
    border-color: var(--yt-red);
    box-shadow: 0 2px 12px rgba(255,0,0,0.1);
    transform: translateY(-1px);
}
.pt-name { font-size: 13px; font-weight: 600; margin-bottom: 2px; }
.pt-sku { font-size: 10px; color: var(--yt-text-secondary); font-family: 'Roboto Mono', monospace; margin-bottom: 6px; }
.pt-price { font-size: 13px; font-weight: 700; color: var(--yt-red); }
.pt-disc { font-size: 10px; color: var(--success); }
.pt-stock { font-size: 10px; color: var(--yt-text-secondary); margin-top: 4px; }
@keyframes slideIn { from { transform: translateX(20px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
#filterChips { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 0; }

/* Close btn: hidden on desktop, shown on mobile */
.cart-close-btn { display: none !important; }
@media (max-width: 900px) {
    .cart-close-btn { display: flex !important; }
    .pay-grid { grid-template-columns: 1fr !important; }
}
</style>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
