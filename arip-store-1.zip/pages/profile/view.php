<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Profil Saya';
$activePage = 'profile';

$user = getCurrentUser();
if (!$user) {
    header('Location: ' . BASE_URL . '/pages/auth/logout.php');
    exit;
}

// Stats
$totalTrx   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM transaksi WHERE kasir_id = " . (int)$user['id']))['c'];
$totalOmzet = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as s FROM transaksi WHERE kasir_id = " . (int)$user['id']))['s'];
$todayTrx   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM transaksi WHERE kasir_id = " . (int)$user['id'] . " AND DATE(created_at) = CURDATE()"))['c'];

// Recent transactions
$recentTrx = mysqli_query($conn, "
    SELECT t.* FROM transaksi t 
    WHERE t.kasir_id = " . (int)$user['id'] . "
    ORDER BY t.created_at DESC LIMIT 5
");

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Profil Saya</div>
            <div class="page-subtitle">Informasi akun dan statistik</div>
        </div>
        <a href="<?= BASE_URL ?>/pages/profile/edit.php" class="btn btn-primary">
            <span class="material-symbols-rounded">edit</span> Edit Profil
        </a>
    </div>

    <!-- Profile Header Card -->
    <div class="profile-header">
        <div class="profile-avatar-lg">
            <?= strtoupper(substr($user['username'], 0, 1)) ?>
        </div>
        <div class="profile-info">
            <div class="name"><?= esc($user['username']) ?></div>
            <div class="role">
                <span class="badge <?= $user['role'] === 'admin' ? 'badge-red' : 'badge-blue' ?>" style="font-size:12px;padding:4px 10px">
                    <span class="material-symbols-rounded fill-icon" style="font-size:14px"><?= $user['role'] === 'admin' ? 'admin_panel_settings' : 'badge' ?></span>
                    &nbsp;<?= ucfirst($user['role']) ?>
                </span>
            </div>
            <div style="margin-top:8px;font-size:13px;color:var(--yt-text-secondary);display:flex;gap:16px;flex-wrap:wrap">
                <span>
                    <span class="material-symbols-rounded" style="font-size:16px">email</span>
                    <?= esc($user['email']) ?>
                </span>
                <span>
                    <span class="material-symbols-rounded" style="font-size:16px">calendar_today</span>
                    Bergabung <?= date('d M Y', strtotime($user['created_at'])) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="margin-bottom:24px">
        <div class="stat-card">
            <div class="stat-icon red">
                <span class="material-symbols-rounded fill-icon">receipt_long</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Total Transaksi</div>
                <div class="stat-value"><?= number_format($totalTrx) ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <span class="material-symbols-rounded fill-icon">payments</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Total Omzet</div>
                <div class="stat-value" style="font-size:16px"><?= formatRupiah($totalOmzet) ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon blue">
                <span class="material-symbols-rounded fill-icon">today</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Transaksi Hari Ini</div>
                <div class="stat-value"><?= number_format($todayTrx) ?></div>
            </div>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="profile-grid">
        <!-- Account Info -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Informasi Akun</div>
                <a href="<?= BASE_URL ?>/pages/profile/edit.php" class="btn btn-sm btn-outline">
                    <span class="material-symbols-rounded" style="font-size:16px">edit</span> Edit
                </a>
            </div>
            <div class="card-body">
                <table style="width:100%;border-collapse:collapse">
                    <?php
                    $rows = [
                        ['ID Akun', '#' . $user['id']],
                        ['Username', $user['username']],
                        ['Email', $user['email']],
                        ['Role', ucfirst($user['role'])],
                        ['Bergabung', date('d F Y', strtotime($user['created_at']))],
                        ['Terakhir Diubah', date('d F Y H:i', strtotime($user['updated_at']))],
                    ];
                    foreach ($rows as $r):
                    ?>
                    <tr style="border-bottom:1px solid var(--yt-border)">
                        <td style="padding:10px 0;font-size:13px;color:var(--yt-text-secondary);width:140px;vertical-align:top"><?= $r[0] ?></td>
                        <td style="padding:10px 0;font-size:14px;font-weight:500"><?= esc($r[1]) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>

        <!-- Recent Transactions -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Transaksi Terakhir</div>
                <a href="<?= BASE_URL ?>/pages/transaksi/index.php" class="btn btn-sm btn-outline">Semua</a>
            </div>
            <?php if (mysqli_num_rows($recentTrx) > 0): ?>
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Total</th>
                            <th>Waktu</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($t = mysqli_fetch_assoc($recentTrx)): ?>
                    <tr>
                        <td><span class="sku-badge"><?= esc($t['kode']) ?></span></td>
                        <td class="fw-bold text-red"><?= formatRupiah($t['grand_total']) ?></td>
                        <td style="font-size:12px;color:var(--yt-text-secondary)"><?= date('d/m H:i', strtotime($t['created_at'])) ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>/pages/transaksi/struk.php?id=<?= $t['id'] ?>" target="_blank" class="btn-icon">
                                <span class="material-symbols-rounded" style="font-size:16px">print</span>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="es-icon">🧾</div>
                <h3>Belum ada transaksi</h3>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
@media (max-width: 700px) {
    .profile-grid { grid-template-columns: 1fr !important; }
    .profile-header { flex-direction: column; align-items: flex-start; }
}
</style>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
