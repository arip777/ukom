<?php
require_once __DIR__ . '/../../config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Edit Profil';
$activePage = 'profile';

$user = getCurrentUser();
if (!$user) {
    header('Location: ' . BASE_URL . '/pages/auth/logout.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tab = $_POST['tab'] ?? 'info';

    if ($tab === 'info') {
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');

        if (empty($username)) $errors[] = 'Username wajib diisi.';
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email tidak valid.';

        if (empty($errors)) {
            $u = mysqli_real_escape_string($conn, $username);
            $e = mysqli_real_escape_string($conn, $email);
            $id = (int)$user['id'];

            $check = mysqli_query($conn, "SELECT id FROM kasir WHERE (username='$u' OR email='$e') AND id != $id LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                $errors[] = 'Username atau email sudah digunakan akun lain.';
            } else {
                mysqli_query($conn, "UPDATE kasir SET username='$u', email='$e' WHERE id=$id");
                $_SESSION['username'] = $username;
                setFlash('success', 'Profil berhasil diperbarui.');
                header('Location: ' . BASE_URL . '/pages/profile/edit.php');
                exit;
            }
        }
    } elseif ($tab === 'password') {
        $currentPw  = $_POST['current_password'] ?? '';
        $newPw      = $_POST['new_password'] ?? '';
        $confirmPw  = $_POST['confirm_password'] ?? '';

        if (empty($currentPw)) $errors[] = 'Password saat ini wajib diisi.';
        if (strlen($newPw) < 6) $errors[] = 'Password baru minimal 6 karakter.';
        if ($newPw !== $confirmPw) $errors[] = 'Konfirmasi password tidak cocok.';

        if (empty($errors)) {
            if (!password_verify($currentPw, $user['password'])) {
                $errors[] = 'Password saat ini salah.';
            } else {
                $hash = mysqli_real_escape_string($conn, password_hash($newPw, PASSWORD_BCRYPT));
                $id = (int)$user['id'];
                mysqli_query($conn, "UPDATE kasir SET password='$hash' WHERE id=$id");
                setFlash('success', 'Password berhasil diubah.');
                header('Location: ' . BASE_URL . '/pages/profile/edit.php');
                exit;
            }
        }
    }
}

$activeTab = $_POST['tab'] ?? ($_GET['tab'] ?? 'info');

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-container" style="max-width:760px">
    <?php include __DIR__ . '/../../includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Edit Profil</div>
            <div class="page-subtitle">Perbarui informasi akun Anda</div>
        </div>
        <a href="<?= BASE_URL ?>/pages/profile/view.php" class="btn btn-outline">
            <span class="material-symbols-rounded">arrow_back</span> Kembali
        </a>
    </div>

    <!-- Profile Card Header -->
    <div class="profile-header" style="margin-bottom:20px">
        <div class="profile-avatar-lg">
            <?= strtoupper(substr($user['username'], 0, 1)) ?>
        </div>
        <div class="profile-info">
            <div class="name"><?= esc($user['username']) ?></div>
            <div style="margin-top:4px">
                <span class="badge <?= $user['role'] === 'admin' ? 'badge-red' : 'badge-blue' ?>"><?= ucfirst($user['role']) ?></span>
            </div>
            <div style="font-size:13px;color:var(--yt-text-secondary);margin-top:6px"><?= esc($user['email']) ?></div>
        </div>
    </div>

    <!-- Tab Navigation -->
    <div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid var(--yt-border)">
        <a href="?tab=info" style="padding:10px 20px;font-size:14px;font-weight:500;text-decoration:none;color:<?= $activeTab === 'info' ? 'var(--yt-red)' : 'var(--yt-text-secondary)' ?>;border-bottom:2px solid <?= $activeTab === 'info' ? 'var(--yt-red)' : 'transparent' ?>;margin-bottom:-2px">
            <span class="material-symbols-rounded" style="font-size:18px">person</span> Informasi Akun
        </a>
        <a href="?tab=password" style="padding:10px 20px;font-size:14px;font-weight:500;text-decoration:none;color:<?= $activeTab === 'password' ? 'var(--yt-red)' : 'var(--yt-text-secondary)' ?>;border-bottom:2px solid <?= $activeTab === 'password' ? 'var(--yt-red)' : 'transparent' ?>;margin-bottom:-2px">
            <span class="material-symbols-rounded" style="font-size:18px">lock</span> Ubah Password
        </a>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <div>
            <span class="material-symbols-rounded fill-icon">error</span>
            <?php foreach ($errors as $err): ?>
            <div><?= esc($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($activeTab === 'info'): ?>
    <!-- Info Tab -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Informasi Akun</div>
        </div>
        <form method="POST">
            <input type="hidden" name="tab" value="info">
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-control" 
                        value="<?= esc($_POST['username'] ?? $user['username']) ?>" required>
                    <div class="form-hint">Username digunakan untuk login dan identifikasi di transaksi</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control"
                        value="<?= esc($_POST['email'] ?? $user['email']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <input type="text" class="form-control" value="<?= ucfirst($user['role']) ?>" 
                        readonly style="background:var(--yt-hover);color:var(--yt-text-secondary)">
                    <div class="form-hint">Role hanya dapat diubah oleh admin</div>
                </div>
            </div>
            <div class="modal-footer" style="padding:16px 20px;border-top:1px solid var(--yt-border);display:flex;justify-content:flex-end;gap:8px">
                <a href="<?= BASE_URL ?>/pages/profile/view.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">
                    <span class="material-symbols-rounded">save</span> Simpan Perubahan
                </button>
            </div>
        </form>
    </div>

    <?php else: ?>
    <!-- Password Tab -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Ubah Password</div>
        </div>
        <form method="POST">
            <input type="hidden" name="tab" value="password">
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label">Password Saat Ini *</label>
                    <input type="password" name="current_password" class="form-control" required
                        placeholder="Masukkan password saat ini">
                </div>
                <div class="form-group">
                    <label class="form-label">Password Baru *</label>
                    <input type="password" name="new_password" id="newPw" class="form-control" required
                        minlength="6" placeholder="Minimal 6 karakter">
                </div>
                <div class="form-group">
                    <label class="form-label">Konfirmasi Password Baru *</label>
                    <input type="password" name="confirm_password" id="confirmPw" class="form-control" required
                        placeholder="Ulangi password baru" oninput="checkPwMatch()">
                    <div id="pwMatchMsg" style="font-size:12px;margin-top:4px"></div>
                </div>

                <div class="alert alert-info" style="font-size:13px">
                    <span class="material-symbols-rounded fill-icon">info</span>
                    Password baru minimal 6 karakter. Setelah diubah, gunakan password baru untuk login berikutnya.
                </div>
            </div>
            <div style="padding:16px 20px;border-top:1px solid var(--yt-border);display:flex;justify-content:flex-end;gap:8px">
                <a href="<?= BASE_URL ?>/pages/profile/view.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">
                    <span class="material-symbols-rounded">lock_reset</span> Ubah Password
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<script>
function checkPwMatch() {
    var np = document.getElementById('newPw').value;
    var cp = document.getElementById('confirmPw').value;
    var msg = document.getElementById('pwMatchMsg');
    if (cp.length === 0) { msg.textContent = ''; return; }
    if (np === cp) {
        msg.style.color = 'var(--success)';
        msg.textContent = '✓ Password cocok';
    } else {
        msg.style.color = 'var(--danger)';
        msg.textContent = '✗ Password tidak cocok';
    }
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
