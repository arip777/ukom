<?php
require_once __DIR__ . '/../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Username dan password wajib diisi.';
    } else {
        $conn = getDB();
        $u = mysqli_real_escape_string($conn, $username);
        $result = mysqli_query($conn, "SELECT * FROM kasir WHERE username = '$u' OR email = '$u' LIMIT 1");
        $user = mysqli_fetch_assoc($result);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['kasir_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Arip Store</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <style>.material-symbols-rounded { font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24; vertical-align:middle; font-size:22px; }</style>
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="auth-logo-icon">A</div>
            <div class="auth-title">Arip Store</div>
            <div class="auth-subtitle">Point of Sale System &bull; <?= APP_LOCATION ?></div>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger" style="margin-bottom:16px">
            <span class="material-symbols-rounded">error</span> <?= esc($error) ?>
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label class="form-label">Username atau Email</label>
            <div class="input-group">
                <span class="input-addon"><span class="material-symbols-rounded">person</span></span>
                <input type="text" name="username" id="username" class="form-control" 
                    placeholder="Masukkan username atau email"
                    value="<?= esc($_POST['username'] ?? '') ?>" autocomplete="username" autofocus>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-group">
                <span class="input-addon"><span class="material-symbols-rounded">lock</span></span>
                <input type="password" name="password" id="password" class="form-control" 
                    placeholder="Masukkan password" autocomplete="current-password">
                <button type="button" class="btn btn-outline" id="togglePw" style="border-left:none;border-radius:0 8px 8px 0;padding:8px 10px;">
                    <span class="material-symbols-rounded" style="font-size:18px">visibility</span>
                </button>
            </div>
        </div>

        <button class="btn btn-primary" style="width:100%;justify-content:center;padding:11px;" id="loginBtn" 
            onclick="doLogin()">
            <span class="material-symbols-rounded">login</span> Masuk
        </button>

        <div style="text-align:center;margin-top:20px;font-size:13px;color:var(--yt-text-secondary)">
            Belum punya akun? 
            <a href="<?= BASE_URL ?>/pages/auth/register.php" style="color:var(--yt-red);font-weight:500;text-decoration:none">Daftar sekarang</a>
        </div>
    </div>
</div>

<form method="POST" id="loginForm" style="display:none">
    <input type="hidden" name="username" id="hUsername">
    <input type="hidden" name="password" id="hPassword">
</form>

<script>
document.getElementById('togglePw').addEventListener('click', function() {
    var pw = document.getElementById('password');
    var icon = this.querySelector('span');
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.textContent = 'visibility_off';
    } else {
        pw.type = 'password';
        icon.textContent = 'visibility';
    }
});

function doLogin() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    document.getElementById('hUsername').value = username;
    document.getElementById('hPassword').value = password;
    document.getElementById('loginForm').submit();
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doLogin();
});
</script>
</body>
</html>
