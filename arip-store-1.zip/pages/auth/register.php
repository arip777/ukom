<?php
require_once __DIR__ . '/../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (empty($username) || empty($email) || empty($password)) {
        $error = 'Semua field wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        $conn = getDB();
        $u = mysqli_real_escape_string($conn, $username);
        $e = mysqli_real_escape_string($conn, $email);

        $check = mysqli_query($conn, "SELECT id FROM kasir WHERE username='$u' OR email='$e' LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            $error = 'Username atau email sudah digunakan.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $h = mysqli_real_escape_string($conn, $hash);
            mysqli_query($conn, "INSERT INTO kasir (username, email, password, role) VALUES ('$u', '$e', '$h', 'kasir')");
            $success = 'Akun berhasil dibuat! Silakan login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Arip Store</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <style>.material-symbols-rounded { font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24; vertical-align:middle; font-size:22px; }</style>
</head>
<body>
<div class="auth-page">
    <div class="auth-card" style="max-width:460px">
        <div class="auth-logo">
            <div class="auth-logo-icon">A</div>
            <div class="auth-title">Daftar Akun</div>
            <div class="auth-subtitle">Buat akun kasir baru</div>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger"><span class="material-symbols-rounded">error</span> <?= esc($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success"><span class="material-symbols-rounded">check_circle</span> <?= esc($success) ?></div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" 
                    value="<?= esc($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Masukkan email"
                    value="<?= esc($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
            </div>
            <div class="form-group">
                <label class="form-label">Konfirmasi Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px;">
                <span class="material-symbols-rounded">how_to_reg</span> Daftar
            </button>
        </form>
        <?php endif; ?>

        <div style="text-align:center;margin-top:20px;font-size:13px;color:var(--yt-text-secondary)">
            Sudah punya akun? 
            <a href="<?= BASE_URL ?>/pages/auth/login.php" style="color:var(--yt-red);font-weight:500;text-decoration:none">Login</a>
        </div>
    </div>
</div>
</body>
</html>
