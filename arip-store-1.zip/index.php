<?php
require_once __DIR__ . '/config.php';
requireLogin();

$conn = getDB();
$pageTitle = 'Dashboard';
$activePage = 'dashboard';

// Stats
$totalProduk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM produk"))['total'];
$totalKategori = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM kategori"))['total'];
$totalKasir = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM kasir"))['total'];
$totalTransaksiHari = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM transaksi WHERE DATE(created_at) = CURDATE()"))['total'];
$omzetHari = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi WHERE DATE(created_at) = CURDATE()"))['total'];
$omzetBulan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"))['total'];

// Transaksi terakhir
$recentTrx = mysqli_query($conn, "
    SELECT t.*, k.username 
    FROM transaksi t 
    JOIN kasir k ON k.id = t.kasir_id 
    ORDER BY t.created_at DESC 
    LIMIT 8
");

// Produk low stock
$lowStock = mysqli_query($conn, "
    SELECT p.*, k.nama as kategori_nama 
    FROM produk p 
    JOIN kategori k ON k.id = p.kategori_id
    WHERE p.stock <= 10 
    ORDER BY p.stock ASC 
    LIMIT 6
");

include __DIR__ . '/includes/header.php';
?>

<div class="page-container">
    <?php include __DIR__ . '/includes/flash.php'; ?>

    <div class="page-header">
        <div>
            <div class="page-title">Dashboard</div>
            <div class="page-subtitle"><?= date('l, d F Y') ?> &mdash; <?= APP_LOCATION ?></div>
        </div>
        <a href="<?= BASE_URL ?>/pages/kasir/index.php" class="btn btn-primary">
            <span class="material-symbols-rounded">point_of_sale</span> Buka Kasir
        </a>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon red">
                <span class="material-symbols-rounded fill-icon">receipt_long</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Transaksi Hari Ini</div>
                <div class="stat-value"><?= number_format($totalTransaksiHari) ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <span class="material-symbols-rounded fill-icon">payments</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Omzet Hari Ini</div>
                <div class="stat-value" style="font-size:16px"><?= formatRupiah($omzetHari) ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon blue">
                <span class="material-symbols-rounded fill-icon">inventory_2</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Total Produk</div>
                <div class="stat-value"><?= number_format($totalProduk) ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon orange">
                <span class="material-symbols-rounded fill-icon">bar_chart</span>
            </div>
            <div class="stat-info">
                <div class="stat-label">Omzet Bulan Ini</div>
                <div class="stat-value" style="font-size:16px"><?= formatRupiah($omzetBulan) ?></div>
            </div>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;" class="dash-grid">
        <!-- Recent Transactions -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Transaksi Terbaru</div>
                <a href="<?= BASE_URL ?>/pages/transaksi/index.php" class="btn btn-sm btn-outline">Lihat Semua</a>
            </div>
            <?php if (mysqli_num_rows($recentTrx) > 0): ?>
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Kasir</th>
                            <th>Total</th>
                            <th>Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($trx = mysqli_fetch_assoc($recentTrx)): ?>
                        <tr>
                            <td><span class="sku-badge"><?= esc($trx['kode']) ?></span></td>
                            <td><?= esc($trx['username']) ?></td>
                            <td class="fw-bold text-red"><?= formatRupiah($trx['grand_total']) ?></td>
                            <td class="text-muted" style="font-size:12px"><?= date('H:i', strtotime($trx['created_at'])) ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="es-icon">🧾</div>
                <h3>Belum ada transaksi hari ini</h3>
            </div>
            <?php endif; ?>
        </div>

        <!-- Low Stock -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Stok Menipis</div>
                <a href="<?= BASE_URL ?>/pages/produk/index.php" class="btn btn-sm btn-outline">Kelola Produk</a>
            </div>
            <?php if (mysqli_num_rows($lowStock) > 0): ?>
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>SKU</th>
                            <th>Stok</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($p = mysqli_fetch_assoc($lowStock)): ?>
                        <tr>
                            <td><?= esc($p['name']) ?></td>
                            <td><span class="sku-badge"><?= esc($p['sku']) ?></span></td>
                            <td>
                                <span class="badge <?= $p['stock'] == 0 ? 'badge-red' : 'badge-orange' ?>">
                                    <?= $p['stock'] == 0 ? 'Habis' : $p['stock'] . ' pcs' ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="es-icon">✅</div>
                <h3>Stok aman</h3>
                <p>Semua produk memiliki stok yang cukup</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
@media (max-width: 700px) {
    .dash-grid { grid-template-columns: 1fr !important; }
}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>
