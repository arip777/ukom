-- Arip Store POS Database
-- MySQL 5.7

CREATE DATABASE IF NOT EXISTS arip_store_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE arip_store_db;

-- Tabel Kategori
CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    alias CHAR(3) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel Kasir
CREATE TABLE IF NOT EXISTS kasir (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','kasir') DEFAULT 'kasir',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel Produk
CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    sku VARCHAR(50) NOT NULL UNIQUE,
    kategori_id INT NOT NULL,
    berat INT NOT NULL DEFAULT 0 COMMENT 'dalam gram',
    price DECIMAL(15,2) NOT NULL DEFAULT 0,
    discount DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'dalam persen',
    stock INT NOT NULL DEFAULT 0,
    sold INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel Transaksi
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) NOT NULL UNIQUE,
    kasir_id INT NOT NULL,
    grand_total DECIMAL(15,2) NOT NULL DEFAULT 0,
    amount_paid DECIMAL(15,2) NOT NULL DEFAULT 0,
    change_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kasir_id) REFERENCES kasir(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel Detail Transaksi
CREATE TABLE IF NOT EXISTS transaksi_detail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaksi_id INT NOT NULL,
    produk_id INT NOT NULL,
    produk_name VARCHAR(200) NOT NULL,
    produk_sku VARCHAR(50) NOT NULL,
    qty INT NOT NULL DEFAULT 1,
    price DECIMAL(15,2) NOT NULL DEFAULT 0,
    discount DECIMAL(5,2) NOT NULL DEFAULT 0,
    subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE,
    FOREIGN KEY (produk_id) REFERENCES produk(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Data Kategori
INSERT INTO kategori (nama, alias) VALUES
('Minuman', 'MNM'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Kebersihan', 'KBR'),
('Rokok', 'RKK');

-- Seed Data Kasir (admin default)
INSERT INTO kasir (username, email, password, role) VALUES
('admin', 'admin@admin.com', '$2y$10$1BBxdDE55zv5GUImeM2NNuTPNeUvqjny0UJSTG48yLqn9RmbxMTIy', 'admin');

-- Seed Data Produk
INSERT INTO produk (name, sku, kategori_id, berat, price, discount, stock, sold) VALUES
('Aqua Botol', 'MNM-AQUA-330', 1, 330, 3000, 0, 100, 50),
('Indomie Goreng', 'MKN-INDOMIE-85', 2, 85, 3500, 0, 200, 120),
('Chitato Original', 'SNK-CHITATO-68', 3, 68, 12000, 10, 50, 30),
('Sabun Lifebuoy', 'KBR-LIFEBUOY-90', 4, 90, 8500, 0, 60, 20),
('Gudang Garam Merah', 'RKK-GGMERAH-12', 5, 12, 25000, 0, 80, 45);
